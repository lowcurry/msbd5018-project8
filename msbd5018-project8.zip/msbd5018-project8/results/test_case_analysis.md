# Selected main-test error cases

All three test prediction caches contain 5,000 distinct IDs and match the frozen model configuration and text hashes. The qualitative review excluded the 600 IDs reserved for independent label review. It ordered the other 4,400 IDs by SHA-256 of the UTF-8 string `qualitative-v1|` followed by the ID, then inspected examples within the three prediction patterns below. Each case illustrates a clear, isolated issue in the complete passage. These examples use the original VitaminC labels and illustrate mechanisms. Frequency estimates come from the full test tables.

| VitaminC ID | Original label | Jev | NLI | FLAN-T5 | Frozen Jev route |
|---|---|---|---|---|---|
| `5ee3932ac9e77c0008cc966c_2` | I | S | I | C | Retained Jev |
| `5ece9462c9e77c0008466630_2` | C | S | S | C | Retained Jev |
| `5ec5598dc9e77c000842c393_2` | I | I | I | S | Retained Jev |

## Temporal scope

The New York COVID-19 claim specifies late March 2020. The passage gives the same one-third share for early April 2020, leaving the late-March share open. Jev assigned support, NLI agreed with the original insufficient-evidence label, and FLAN-T5 assigned contradiction. This was the fourth hash-ranked match among Jev false-support cases with original label I and a temporal marker in the claim. The preceding candidates combined temporal and entity or document-reference questions, or already supplied the stated date.

## Quantifier boundary

The Calgary airport claim says fewer than three Canadian airports had more aircraft movements. The passage ranks Calgary fourth nationally on that measure, which implies three airports ahead. Jev and NLI assigned support and FLAN-T5 agreed with the original contradiction label. This was the second hash-ranked match among Jev false-support cases with original label C and a numeric marker. The first involved ambiguous identity or scope across references to albums and release dates.

## Related occupation

The Todrick Hall passage lists several occupations, including singer and rapper. It leaves his work as a songwriter unspecified. Jev and NLI agreed with the original insufficient-evidence label and FLAN-T5 assigned support. This was the first hash-ranked case where Jev matched a non-S original label and FLAN-T5 predicted S. Together with the Calgary case, it shows that replacing Jev with the fallback can correct or introduce false support. The frozen policy retained Jev on both examples.
