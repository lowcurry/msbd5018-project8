# MSBD 5018 Group 16 Automated Evaluation

Evaluating Jev for RAG Citation Verification

The held-out VitaminC-real test contains 5,000 pairs. This table uses the original dataset labels.

| System | Macro-F1 | Accuracy | Support precision | False support rate | LLM calls |
|---|---:|---:|---:|---:|---:|
| Jev 1.13 Choice | 0.8126 | 0.8386 | 0.9121 | 0.0878 | 0 |
| DeBERTa NLI | 0.5052 | 0.5072 | 0.8103 | 0.1118 | 0 |
| All-FLAN-T5-base | 0.2575 | 0.3058 | 0.5039 | 0.0253 | 5,000 |
| Frozen Jev policy | 0.8124 | 0.8386 | 0.9121 | 0.0878 | 2 |
| Frozen NLI policy | 0.5052 | 0.5072 | 0.8103 | 0.1118 | 0 |

Threshold 1/3. The frozen Jev policy minus all-FLAN macro-F1 difference was +0.5548. The 5,000-replicate paired article bootstrap gave a one-sided 95% lower bound of +0.5407 and a two-sided 95% interval of [+0.5380, +0.5708]. The policy met the −0.02 non-inferiority criterion.

The policy used 2 LLM calls. This comparison applies to the development-selected local FLAN-T5-base judge.

The matched 100-pair workload was repeated three times at concurrency one. Jev policy p50/p95 measured 692/1113 ms, while all-FLAN measured 104/122 ms.

Independent adjudication of the 600-pair label audit and review of the 200 language contrast groups are pending.

See metrics_main.csv, bootstrap_primary.json and the matched-budget files under results/test for reproducible metrics.
