"""Report actual attempts, offline deployment estimates, and matched live resources separately."""

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

from evaluate import digest, read_csv, read_jsonl, unique, write_csv, write_json


def read_ledgers(paths):
    events = {}
    loads = []
    for path in paths:
        for line in read_jsonl(path):
            if line.get("event") == "load":
                loads.append({"ledger": path.name, **line})
                continue
            identifier, event = line["attempt_id"], line["event"]
            if event not in {"start", "finish"}:
                raise ValueError(f"{path}: invalid attempt event {event!r}")
            pair = events.setdefault(identifier, {})
            if event in pair:
                if pair[event] == line:
                    continue
                raise ValueError(f"{path}: conflicting {event} for attempt {identifier}")
            pair[event] = line
    attempts = {}
    for identifier, pair in events.items():
        if "start" not in pair:
            raise ValueError(f"attempt {identifier} has a finish but no start")
        start = pair["start"]
        finish = pair.get("finish")
        if finish is not None:
            for field in ("id", "model", "deployment", "scope", "subset", "config_hash", "batch_id", "method", "repeat"):
                if start.get(field) != finish.get(field):
                    raise ValueError(f"attempt {identifier}: {field} differs across start and finish")
        attempts[identifier] = {**(finish or start), "finished": finish is not None}
    return attempts, loads


def token_count(attempt, field):
    value = attempt.get(field)
    if value is not None and (type(value) is not int or value < 0):
        raise ValueError(f"invalid {field} in attempt {attempt['attempt_id']}")
    return value


def price_attempt(attempt, prices, billing):
    identifier = attempt["attempt_id"]
    if identifier in billing:
        return billing[identifier], "billing_override"
    rate = prices.get(attempt["model"])
    if rate is None:
        return None, "unpriced"
    if not attempt["finished"]:
        return None, "incomplete"
    total = 0.
    for direction in ("input", "output"):
        amount = rate[f"{direction}_per_million"]
        tokens = token_count(attempt, f"{direction}_tokens")
        if amount and tokens is None:
            return None, "usage_missing"
        total += amount * (tokens or 0) / 1_000_000
    return total, "published_rate"


def aggregate(attempts, prices, billing):
    api = [a for a in attempts if a["deployment"] != "local"]
    local = [a for a in attempts if a["deployment"] == "local"]
    bills = [price_attempt(a, prices, billing) for a in api]
    known_amount = sum(amount for amount, _ in bills if amount is not None)
    unknown = sum(amount is None for amount, _ in bills)
    local_batches = {}
    for attempt in local:
        identifier = attempt["batch_id"]
        if attempt["finished"]:
            elapsed = attempt["elapsed_ms"]
            if not isinstance(elapsed, (float, int)) or not math.isfinite(elapsed) or elapsed < 0:
                raise ValueError(f"invalid elapsed_ms in local batch {identifier}")
            if identifier in local_batches and local_batches[identifier] != elapsed:
                raise ValueError(f"inconsistent elapsed_ms in local batch {identifier}")
            local_batches[identifier] = elapsed
    unknown_batches = {a["batch_id"] for a in local} - local_batches.keys()
    report = {
        "attempts": len(attempts), "finished_attempts": sum(a["finished"] for a in attempts),
        "unfinished_attempts": sum(not a["finished"] for a in attempts),
        "attempt_failures": sum(a["finished"] and bool(a.get("error_type")) for a in attempts),
        "retries": sum(a["number"] > 1 for a in attempts),
        "api_attempts": len(api), "api_attempts_without_cost": unknown,
        "api_priced_subtotal_usd": known_amount, "api_total_usd": None if unknown else known_amount,
        "api_attempts_billing_reconciled": sum(source == "billing_override" for _, source in bills),
        "api_amount_basis": "billing_reconciled" if api and all(s == "billing_override" for _, s in bills)
        else ("published_rate_and_optional_billing" if api else "no_api_attempts"),
        "local_pair_attempts": len(local), "local_batches": len(local_batches),
        "local_unmeasured_batches": len(unknown_batches),
        "local_compute_measured_seconds": sum(local_batches.values()) / 1000,
        "local_compute_amount_usd": None,
    }
    for kind, pool in (("api", api), ("local", local)):
        for direction in ("input", "output"):
            counts = [token_count(a, f"{direction}_tokens") for a in pool]
            report[f"{kind}_{direction}_known_tokens"] = sum(n for n in counts if n is not None)
            report[f"{kind}_{direction}_unknown_attempts"] = sum(n is None for n in counts)
    return report


def summarize_actual(attempts, prices, billing):
    groups = defaultdict(list)
    for attempt in attempts.values():
        basis = "real_chain_measurement" if attempt["scope"] == "live_benchmark" else "actual_evaluation"
        groups[basis, "TOTAL", "", "", "", ""].append(attempt)
        key = (basis, attempt["scope"], attempt["subset"], attempt.get("method") or "",
               attempt["model"], attempt["config_hash"])
        groups[key].append(attempt)
    rows = []
    for (basis, scope, subset, method, model, config), group in sorted(groups.items()):
        rows.append({"basis": basis, "scope": scope, "subset": subset, "method": method,
                     "model": model, "config_hash": config, **aggregate(group, prices, billing)})
    return rows


def bool_value(value):
    if value not in {"True", "False"}:
        raise ValueError(f"invalid CSV Boolean {value!r}")
    return value == "True"


def test_records(predictions, integrity, attempts, model):
    path = predictions / f"{model}_test.jsonl"
    if digest(path) != integrity["test_cache_sha256"][model]:
        raise ValueError(f"{path}: cache differs from the scored test")
    records = unique(read_jsonl(path), "id", path)
    for identifier, row in records.items():
        for event in row["attempts"]:
            aid = event["attempt_id"]
            if aid not in attempts:
                raise ValueError(f"{aid}: a scored test attempt is missing from its ledger")
            logged = attempts[aid]
            if (
                not logged["finished"] or logged["id"] != identifier or logged["model"] != row["model"]
                or logged["config_hash"] != row["config_hash"] or logged["subset"] != "test"
                or any(logged.get(field) != event.get(field) for field in (
                    "input_tokens", "output_tokens", "elapsed_ms", "deployment", "batch_id"
                ))
            ):
                raise ValueError(f"{aid}: scored test prediction and attempt ledger disagree")
    return records


def amortized_local_ms(attempts):
    total = 0.
    for attempt in attempts:
        size = attempt.get("batch_size")
        if type(size) is not int or size < 1:
            raise ValueError(f"invalid batch_size in attempt {attempt['attempt_id']}")
        total += attempt["elapsed_ms"] / size
    return total


def observed_routing_ms(benchmark):
    if benchmark is None:
        return None
    path = benchmark / "latency_runs.csv"
    if not path.is_file():
        return None
    rows = [row for row in read_csv(path) if row["method"] == "jev-to-llm"]
    if not rows:
        return None
    if len({(row["repeat"], row["id"]) for row in rows}) != 300 or len(rows) != 300:
        raise ValueError("router overhead requires a complete matched 100 × 3 live benchmark")
    values = [float(row["route_ms"]) for row in rows]
    if any(not math.isfinite(value) or value < 0 for value in values):
        raise ValueError("invalid measured router overhead")
    return sum(values) / len(values)


def deployment_estimates(args, attempts, prices):
    root = args.results
    integrity = json.loads((root / "run_integrity.json").read_text(encoding="utf-8"))
    path = root / "routing_test.csv"
    if digest(path) != integrity["routing_test_sha256"]:
        raise ValueError("routing records differ from the scored test")
    routing = [row for row in read_csv(path) if row["system"] == "jev-to-llm"]
    route = unique(routing, "id", path)
    jev, llm = (test_records(args.predictions, integrity, attempts, model) for model in ("jev", "llm"))
    if route.keys() != jev.keys() or route.keys() != llm.keys() or len(route) != integrity["test_n"]:
        raise ValueError("deployment inputs do not match the frozen test")
    modes = {row["mode"] for row in routing}
    if len(modes) != 1 or not modes <= {"cascade", "direct_all_llm"}:
        raise ValueError("deployment route has multiple or invalid modes")
    is_cascade = modes == {"cascade"}
    measured_route = observed_routing_ms(args.benchmark) if is_cascade else None
    outputs = []
    for name, first_stage, fallback in (
        ("all-llm", [], list(llm.values())),
        ("jev-to-llm", list(jev.values()) if is_cascade else [],
         [llm[identifier] for identifier, row in route.items() if bool_value(row["llm_called"])]),
    ):
        if not is_cascade and len(fallback) != len(route):
            raise ValueError("a direct all-LLM policy must call the LLM for every test pair")
        jev_calls = [attempts[a["attempt_id"]] for row in first_stage for a in row["attempts"]]
        llm_calls = [attempts[a["attempt_id"]] for row in fallback for a in row["attempts"]]
        total = aggregate(jev_calls + llm_calls, prices, {})
        for field in ("local_batches", "local_unmeasured_batches", "local_compute_measured_seconds"):
            total[f"source_{field}"] = total.pop(field)
        local = [attempt for attempt in llm_calls if attempt["deployment"] == "local"]
        jev_ms = sum(row["elapsed_ms"] for row in first_stage)
        llm_api_ms = sum(row["elapsed_ms"] for row in fallback
                         if any(a["deployment"] != "local" for a in row["attempts"]))
        local_ms = amortized_local_ms(local)
        route_ms = measured_route if first_stage else 0.
        mean_observed_ms = (jev_ms + llm_api_ms + local_ms) / len(route)
        outputs.append({
            "basis": "offline_deployment_estimate", "system": name,
            "mode": "cascade" if first_stage else "direct_all_llm",
            "test_n": len(route), "first_stage_pairs": len(first_stage), "llm_pairs": len(fallback),
            "jev_observed_wall_seconds": jev_ms / 1000,
            "llm_selected_api_observed_wall_seconds": llm_api_ms / 1000,
            "llm_selected_local_amortized_compute_seconds": local_ms / 1000,
            "observed_component_seconds_per_test_pair": mean_observed_ms / 1000,
            "measured_routing_ms_per_pair": route_ms,
            "observed_components_with_routing_seconds_per_pair": (
                (mean_observed_ms + route_ms) / 1000 if route_ms is not None else None
            ),
            "full_chain_latency_estimated": False,
            "timing_scope": "Observed Jev/API time plus selected local compute apportioned by batch size. "
                            "Measured router overhead appears separately. Some local preparation overhead is absent.",
            **total,
        })
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predictions", type=Path, default=Path("predictions"))
    parser.add_argument("--ledger-dir", type=Path, action="append", default=[],
                        help="Additional directory of attempt ledgers, e.g. an unselected candidate's run.")
    parser.add_argument("--results", type=Path, help="Completed evaluate.py test output")
    parser.add_argument("--benchmark", type=Path, help="Live benchmark output, including warm-up ledger")
    parser.add_argument("--prices", type=Path, default=Path("configs/prices.json"))
    parser.add_argument("--billing-overrides", type=Path,
                        help="Optional invoice reconciliation CSV with attempt_id,billed_usd,source")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    try:
        if (args.out / "accounting_inputs.json").exists():
            raise ValueError("resource accounting already exists; choose a fresh output directory")
        price_document = json.loads(args.prices.read_text(encoding="utf-8"))
        if price_document["currency"] != "USD":
            raise ValueError("price file must use USD")
        prices = price_document["prices"]
        for model, rate in prices.items():
            values = [rate[f"{direction}_per_million"] for direction in ("input", "output")]
            if any(not isinstance(x, (int, float)) or not math.isfinite(x) or x < 0 for x in values):
                raise ValueError(f"{model}: invalid price")
            if not rate["checked_date"] or not rate["source"]:
                raise ValueError(f"{model}: missing source or checked date")
        paths = [path for directory in (args.predictions, *args.ledger_dir)
                 for path in sorted(directory.rglob("*.attempts.jsonl"))]
        if args.benchmark is not None:
            paths.append(args.benchmark / "benchmark.attempts.jsonl")
        by_digest = {}
        for path in paths:
            by_digest.setdefault(digest(path), path)
        attempts, loads = read_ledgers(by_digest.values())
        if not attempts:
            raise ValueError("no actual attempt records; resource totals are unavailable")
        billing = {}
        if args.billing_overrides is not None:
            for key, row in unique(read_csv(args.billing_overrides), "attempt_id", args.billing_overrides).items():
                if key not in attempts or attempts[key]["deployment"] == "local":
                    raise ValueError(f"{key}: billing record does not match an API attempt")
                amount = float(row["billed_usd"])
                if not math.isfinite(amount) or amount < 0 or not row["source"].strip():
                    raise ValueError(f"{key}: invalid amount or source")
                billing[key] = amount
        actual = summarize_actual(attempts, prices, billing)
        if args.results is not None:
            simulated = deployment_estimates(args, attempts, prices)
            write_csv(args.out / "deployment_estimates.csv", simulated)
        write_csv(args.out / "resource_summary.csv", actual)
        if loads:
            write_csv(args.out / "model_load_events.csv", loads)
        write_json(args.out / "accounting_inputs.json", {
            "attempt_ledgers": [{"file": str(path), "sha256": digest(path)} for path in paths],
            "prices_sha256": digest(args.prices), "price_document": price_document,
            "billing_overrides_sha256": digest(args.billing_overrides) if args.billing_overrides else None,
            "benchmark_context_sha256": digest(args.benchmark / "measurement_context.json")
            if args.benchmark is not None and (args.benchmark / "measurement_context.json").exists() else None,
            "scope_note": "Totals cover logged attempts only. Benchmark attempts are grouped separately from "
                          "evaluation. A known-usage API subtotal does not establish complete invoice spend. "
                          "No unpriced local compute or router overhead is converted to USD.",
        })
    except (OSError, KeyError, ValueError) as error:
        parser.exit(1, f"Resource accounting failed: {error}\n")


if __name__ == "__main__":
    main()
