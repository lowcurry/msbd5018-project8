# VitaminC source snapshot

Download `vitaminc.zip` from the release link below when preparing data in the coordinator workspace. It is the author's original fact-verification archive. It contains official train, dev and test JSONL files. The preparation script uses records with `revision_type == "real"`. Zip integrity, source size and Git blob hash were checked.

- Bytes 22,381,149
- SHA-256 `49d82dc1690cbee420d18e2c26f687a7937710bb211845d2571430dfd4dc0337`
- Git blob `60f0b2fe99a2587b66be4e841254a26cbd8731f3`
- [Author's repository](https://github.com/TalSchuster/VitaminC)
- [Release archive](https://github.com/TalSchuster/talschuster.github.io/raw/master/static/vitaminc.zip)
- [Publication by Schuster, Fisch and Barzilay](https://aclanthology.org/2021.naacl-main.52/)

See the original `DATA_LICENSE` and any article-specific terms when distributing source text or adaptations.
