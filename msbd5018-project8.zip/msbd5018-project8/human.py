"""Create independent review packets and combine actual human judgments."""
import argparse
import csv
import hashlib
import hmac
import json
import math
from collections import Counter
from pathlib import Path

LABELS = {"S", "C", "I"}
RATINGS = LABELS | {"ambiguous"}
FIELDS = ["review_id", "claim", "passage", "label", "reason", "previously_seen"]
GROUP_FIELDS = [
    "group_id", "axis", "claim_a", "passage_a", "claim_b", "passage_b", "valid_edit", "reason",
]


def read_jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def indexed(rows, field):
    result = {row[field]: row for row in rows}
    if len(result) != len(rows) or "" in result:
        raise ValueError(f"Duplicate or empty {field}")
    return result


def cases(data, track):
    if track == "audit":
        return {
            row["blind_id"]: {"claim": row["claim"], "passage": row["passage"]}
            for row in read_jsonl(data / "audit/audit_blind.jsonl")
        }
    pairs = [
        pair
        for group in read_jsonl(data / "diagnostics/diagnostic_review.jsonl")
        for pair in group["pairs"]
    ]
    # Reviewer sheets cannot expose the source IDs or the constructed-edit suffix.
    salt = bytes.fromhex(file_sha(data / "restricted/audit_mapping.csv"))
    return {
        hmac.new(salt, f"diagnostic-review-v1|{key}".encode(), "sha256").hexdigest()[:24]: pair
        for key, pair in indexed(pairs, "id").items()
    }


def packets(args):
    rows = cases(args.data, args.track)
    target = 600 if args.track == "audit" else 400
    if len(rows) != target:
        raise ValueError(f"Expected {target} distinct review cases, found {len(rows)}")
    for reviewer in ("A", "B"):
        order = sorted(rows, key=lambda key: hashlib.sha256(f"{reviewer}|{key}".encode()).hexdigest())
        write_csv(args.out / f"{args.track}_{reviewer}.csv", FIELDS, (
            {"review_id": key, "claim": rows[key]["claim"], "passage": rows[key]["passage"]}
            for key in order
        ))


def diagnostic_groups(data):
    rows = read_jsonl(data / "diagnostics/diagnostic_review.jsonl")
    groups = indexed(rows, "group_id")
    if Counter(group["axis"] for group in rows) != {
        "number": 50, "time": 50, "entity": 50, "negation": 50,
    }:
        raise ValueError("Expected 50 complete diagnostic groups per axis")
    result = {}
    for group_id, group in groups.items():
        a, b = group["pairs"]
        result[group_id] = {
            "group_id": group_id, "axis": group["axis"], "claim_a": a["claim"],
            "passage_a": a["passage"], "claim_b": b["claim"], "passage_b": b["passage"],
        }
    return result


def group_reviews(path, expected):
    rows = indexed(read_csv(path), "group_id")
    if set(rows) != set(expected):
        raise ValueError(f"{path.name}: group IDs differ from the assigned groups")
    for group_id, row in rows.items():
        if row.get("valid_edit") not in {"yes", "no"} or not row.get("reason", "").strip():
            raise ValueError(f"{path.name}: enter a yes/no decision and reason for {group_id}")
        for field, value in expected[group_id].items():
            if row.get(field, "").replace("\r\n", "\n") != value.replace("\r\n", "\n"):
                raise ValueError(f"{path.name}: {field} changed for {group_id}")
    return rows


def judgments(path, expected, allowed):
    results = indexed(read_csv(path), "review_id")
    if set(results) != set(expected):
        raise ValueError(f"{path.name}: review IDs differ from the assigned cases")
    for key, row in results.items():
        row["label"] = row.get("label", "").strip()
        row["previously_seen"] = row.get("previously_seen", "").strip().lower()
        if row["label"] not in allowed or row["previously_seen"] not in {"yes", "no"}:
            raise ValueError(f"{path.name}: enter a valid label and yes/no exposure for {key}")
        if not row.get("reason", "").strip():
            raise ValueError(f"{path.name}: missing reason for {key}")
        original = expected[key]
        for field in ("claim", "passage"):
            # CSV editors can change line endings. Compare the text after newline normalization.
            if row.get(field, "").replace("\r\n", "\n") != original[field].replace("\r\n", "\n"):
                raise ValueError(f"{path.name}: {field} changed for {key}")
    return results


def agreement(a, b):
    same = sum(a[key]["label"] == b[key]["label"] for key in a)
    valid = [key for key in a if a[key]["label"] in LABELS and b[key]["label"] in LABELS]
    counts_a = Counter(a[key]["label"] for key in valid)
    counts_b = Counter(b[key]["label"] for key in valid)
    observed = sum(a[key]["label"] == b[key]["label"] for key in valid) / len(valid) if valid else None
    expected = sum(counts_a[label] * counts_b[label] for label in LABELS) / len(valid)**2 if valid else None
    kappa = (observed - expected) / (1 - expected) if expected is not None and not math.isclose(expected, 1) else None
    return {
        "assigned_n": len(a), "matched_n_including_ambiguity": same,
        "raw_agreement_including_ambiguity": same / len(a),
        "both_labels_valid_n": len(valid), "agreement_valid": observed,
        "cohen_kappa_valid": kappa,
        "ambiguous_a": sum(row["label"] == "ambiguous" for row in a.values()),
        "ambiguous_b": sum(row["label"] == "ambiguous" for row in b.values()),
        "exposed_a": sum(row["previously_seen"] == "yes" for row in a.values()),
        "exposed_b": sum(row["previously_seen"] == "yes" for row in b.values()),
    }


def combine(args):
    if len({name.strip().casefold() for name in args.reviewers}) != 3 or any(
        not name.strip() for name in args.reviewers
    ):
        raise ValueError("Supply three distinct nonempty reviewer identifiers")
    rows = cases(args.data, args.track)
    a = judgments(args.first, rows, RATINGS)
    b = judgments(args.second, rows, RATINGS)
    pending = {
        key: rows[key] for key in rows
        if a[key]["label"] != b[key]["label"] or a[key]["label"] not in LABELS
        or "yes" in (a[key]["previously_seen"], b[key]["previously_seen"])
    }
    if args.command == "adjudicate":
        write_csv(args.out / f"{args.track}_adjudication.csv",
                  FIELDS + ["reason_a", "reason_b"], (
            {"review_id": key, "claim": row["claim"], "passage": row["passage"],
             "reason_a": a[key]["reason"], "reason_b": b[key]["reason"]}
            for key, row in sorted(pending.items())
        ))
        return

    c = judgments(args.resolved, pending, LABELS | {"unresolved"}) if pending else {}
    verdicts = {}
    for key in rows:
        verdict = c.get(key, a[key])
        exposure = "exposed" if any(
            answer[key]["previously_seen"] == "yes" for answer in (a, b, c) if key in answer
        ) else "blind"
        verdicts[key] = (verdict["label"], exposure)

    if args.track == "audit":
        source = indexed(read_csv(args.data / "restricted/audit_mapping.csv"), "blind_id")
        if set(source) != set(verdicts):
            raise ValueError("Audit mapping IDs differ from reviewer IDs")
        output = [
            {"id": source[key]["id"], "adjudicated_label": label, "exposure_status": exposure}
            for key, (label, exposure) in verdicts.items()
        ]
        fields = ["id", "adjudicated_label", "exposure_status"]
    else:
        source = indexed(read_csv(args.data / "restricted/diagnostic_candidates.csv"), "id")
        if set(source) != {row["id"] for row in rows.values()}:
            raise ValueError("Diagnostic source IDs differ from reviewer IDs")
        groups = diagnostic_groups(args.data)
        edit_a = group_reviews(args.groups_first, groups)
        edit_b = group_reviews(args.groups_second, groups)
        valid_groups = {
            key for key in groups if edit_a[key]["valid_edit"] == edit_b[key]["valid_edit"] == "yes"
        }
        output = []
        for key, (label, exposure) in verdicts.items():
            identifier = rows[key]["id"]
            record = source[identifier]
            output.append({
                "id": identifier, "group_id": record["group_id"], "axis": record["axis"],
                "source_type": record["source_kind"], "adjudicated_label": label,
                "exposure_status": exposure,
                "group_valid": "yes" if record["group_id"] in valid_groups else "no",
            })
        fields = ["id", "group_id", "axis", "source_type", "adjudicated_label",
                  "exposure_status", "group_valid"]

    summary = agreement(a, b)
    summary.update(
        adjudication_n=len(pending), unresolved_n=sum(label == "unresolved" for label, _ in verdicts.values()),
        exposed_n=sum(exposure == "exposed" for _, exposure in verdicts.values()),
        final_label_counts=dict(Counter(label for label, _ in verdicts.values())),
        reviewers=args.reviewers, first_sha256=file_sha(args.first), second_sha256=file_sha(args.second),
        adjudication_sha256=file_sha(args.resolved) if pending else None,
    )
    if args.track == "diagnostics":
        summary.update(
            valid_groups_n=len(valid_groups), group_a_sha256=file_sha(args.groups_first),
            group_b_sha256=file_sha(args.groups_second),
        )
    write_csv(args.out / f"{args.track}_labels.csv", fields, output)
    (args.out / f"{args.track}_agreement.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["packets", "group-packets", "adjudicate", "merge"])
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--track", choices=["audit", "diagnostics"], required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--first", type=Path)
    parser.add_argument("--second", type=Path)
    parser.add_argument("--reviewers", nargs=3, metavar=("A", "B", "C"))
    parser.add_argument("--resolved", type=Path)
    parser.add_argument("--groups-first", type=Path)
    parser.add_argument("--groups-second", type=Path)
    args = parser.parse_args()
    if args.command == "packets":
        packets(args)
    elif args.command == "group-packets":
        if args.track != "diagnostics":
            parser.error("group-packets is available only for diagnostics")
        groups = diagnostic_groups(args.data)
        for reviewer in ("A", "B"):
            write_csv(args.out / f"diagnostic_groups_{reviewer}.csv", GROUP_FIELDS, groups.values())
    else:
        if not (args.first and args.second and args.reviewers):
            parser.error("--first, --second and --reviewers are required for adjudication and merge")
        if args.command == "merge" and not args.resolved:
            parser.error("--resolved is required for merge")
        if args.command == "merge" and args.track == "diagnostics" and not (
            args.groups_first and args.groups_second
        ):
            parser.error("diagnostic merge requires --groups-first and --groups-second")
        combine(args)


if __name__ == "__main__":
    main()
