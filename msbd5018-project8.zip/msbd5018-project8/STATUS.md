# Group 16 项目状态

**2026 年 11 月 6 日 · 冻结主测试与链路计时已完成**

[主要结果](results/MAIN_RESULTS.md) · [复现步骤](README.md) · [人工审核协议](ANNOTATION.md) · [ACL 报告草稿](report/Project8_ACL_Automated_Results.pdf) · [报告源码](report/main.tex) · [汇报演示稿](presentation/Project8_Automated_Results.pptx)

## 已核验的数据

源档案是 VitaminC 作者发布的 22,381,149 字节 ZIP。全部成员通过 CRC 校验，Git blob 和大小与作者仓库记录一致。源档案、许可和哈希在 [data_source](data_source/README.md)。

| 用途 | 条数 | S | C | I | 文章数 |
|---|---:|---:|---:|---:|---:|
| 提示和接口开发 | 200 | 100 | 57 | 43 | 192 |
| 校准 | 2,000 | 991 | 559 | 450 | 625 |
| 阈值与模型选择 | 2,000 | 1,002 | 592 | 406 | 640 |
| 冻结主测试 | 5,000 | 2,505 | 1,438 | 1,057 | 1,629 |

保留官方 split 与合格池类别比例，并排除跨 split 文章、文本、样本和修订冲突。四个样本子集的文章互不重叠。校准集中最大一篇文章有 835 条样本，报告时需解释校准样本的聚集性。主比较按测试文章做配对 bootstrap。

当前共同字节上限为 900。已对开发、测试、诊断和计时输入运行两种 FLAN-T5 和固定 DeBERTa 的实际 tokenizer 检查，观察到的最高长度分别为 465 和 275 tokens，低于 512。运行中保留整段证据。计时输入为按长度分层的 100 条候选。

`handoff/` 中有两套正式独立审核包。主测试盲审为 S150/C150/I300，标注表隐藏标签层。另备 200 组语言诊断候选，四类各 50 组。151 组来自自然修订，49 组为受控否定改写。诊断标签与编辑有效性待两人核验。

## 已完成的真实开发实验

当前清单上的本地模型共完成 10,600 条预测，均返回有效标签。下表使用 2,000 条独立选择集的原标签。

| 模型 | Macro-F1 | Accuracy |
|---|---:|---:|
| DeBERTa NLI | 0.4854 | 0.4820 |
| FLAN-T5-base | 0.2852 | 0.3300 |
| FLAN-T5-small | 0.1655 | 0.2005 |

按预定规则选中 FLAN-T5-base。该模型只识别 1,002 条 S 中的 29 条，选择集 support recall 为 2.9%。这是当前本地比较对象的局限。其温度达到预设拟合上限 100，选择集 ECE 降至 0.0056，同时置信度趋近均匀，须结合独立的匹配预算结果判断路由是否有效。详见 [开发集指标](results/dev/local_development_metrics.csv)、[开发集校准](results/dev/local_development_calibration.csv) 和 [实际开发资源账](results/development_resources/resource_summary.csv)。

## 正式自动评估

全组确认在正式评估前未用 VitaminC 作者发布的 test 样本或文章做过人工试读、调提示词或模型试跑。确认后重建清单，输入与匿名盲审编号均保持一致。模型、数据、阈值、评分规则和负载于 2026 年 11 月 6 日 20:06（UTC+8）冻结。真实 Jev 请求使用 `jev-1.13.0`。密钥通过项目目录外的本机私有环境文件加载。

5,000 条主测试原标签上，独立 Jev、DeBERTa、全量 FLAN 的 macro-F1 分别为 0.8126、0.5052、0.2575。冻结 Jev 方案取得 0.8124，只有两个请求失败触发升级，两次均未纠正原先的失败。相对全量 FLAN 的 macro-F1 差为 +0.5548，配对文章 bootstrap 的 95% 区间为 [+0.5380, +0.5708]。该比较依赖选定的本地 FLAN-T5-base，其主测试 support recall 很低。

计时使用同一 100 条样本，三次重复，并发 1。Jev 方案 p50／p95 为 692／1,113 ms，全量本地 FLAN 为 104／122 ms。实际评估资源、按用量估算的部署资源和实测链路分别记录。见 [计时结果](benchmark/real_chain_comparison.csv) 和 [资源账](results/resources/resource_summary.csv)。

## 待人工完成

主测试的 600 条审计需要两位组员独立盲审和第三人盲裁决。200 组语言对照已经完成预测，仍需两人标注并核验编辑。标注者只接收自己的 [审核包](handoff/README.md) 和 rubric，原标签、模型预测及盲审映射由协调者单独保管。收集结果后用同一冻结清单补算，无需重复调用模型。

课程规定主要结果于 11 月 17 日 23:59 提交，报告及代码数据于 12 月 9 日 23:59 提交。当前 ACL 稿及演示稿包含真实自动评估，正式报告仍需补上人工结果。原 proposal 的 10 月冻结目标已过，冻结记录使用实际日期。

## 证据范围

VitaminC-real 衡量给定单个 passage 的证据关系。ALCE 作者导出的 ASQA 数据经单一明确引用、完整导出段落和 900 字节筛查，发现 374 个唯一候选。外部验证暂缓，后续仍需核实引用来源、原文使用条款和 claim 边界，并重新独立标注 S/C/I。[ALCE 作者评估说明](https://github.com/princeton-nlp/ALCE/blob/main/human_eval/README.md)
