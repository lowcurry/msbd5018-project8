"""Run independent Jev requests with bounded concurrency and durable accounting."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from itertools import islice
from pathlib import Path
import threading
import time

import models


FATAL_ERRORS = {"http_401", "http_403", "resolved_model_mismatch"}


class StopWork(Exception):
    """Raised before starting an attempt after the runner has been stopped."""


def run(args):
    if not 1 <= args.workers <= 32:
        raise ValueError("--workers must be between 1 and 32.")
    if args.limit is not None and (args.subset != "train" or args.limit < 1):
        raise ValueError("A positive --limit is supported only for train smoke checks.")
    spec = models.model_spec(args.config, "jev")
    models.freeze_check(args.freeze, spec, args.data, args.subset)
    rows = models.inputs(args.data, args.subset)
    out = args.predictions / f"jev_{args.subset}.jsonl"
    with models.locked_append(out) as predictions:
        seen = models.existing(predictions, rows, spec, args.subset)
        remaining = [row for row in rows if row["id"] not in seen][:args.limit]
        if not remaining:
            print(f"{out}: {len(seen)}/{len(rows)} cached")
            return
        # Fail before scheduling requests if the credential is unavailable.
        started = time.perf_counter()
        first_backend = models.make_model(spec)
        first_load_ms = 1000 * (time.perf_counter() - started)
        runtime_info = {"config_hash": models.config_hash(spec), "batch_size": 1, **models.runtime(spec)}
        metadata = out.with_suffix(".runtime.json")
        if metadata.exists():
            if models.read_json(metadata) != runtime_info:
                raise ValueError("Runtime settings differ from the prediction cache.")
        else:
            metadata.write_text(models.compact(runtime_info) + "\n", encoding="utf-8")

        with (
            models.locked_append(out.with_suffix(".attempts.jsonl")) as ledger,
            models.locked_append(out.with_suffix(".execution.jsonl")) as execution,
        ):
            session = {
                "workers": args.workers, "subset": args.subset,
                "config_hash": runtime_info["config_hash"],
                "runner_sha256": models.file_digest(Path(__file__)),
            }
            models.append_line(execution, {"event": "start", "utc": models.now(), **session})
            try:
                committed, fatal = execute(
                    args, spec, out, remaining, seen, rows, predictions, ledger,
                    first_backend, first_load_ms,
                )
            except BaseException:
                models.append_line(execution, {"event": "interrupted", "utc": models.now(), **session})
                raise
            models.append_line(execution, {
                "event": "finish", "utc": models.now(), "committed": committed,
                "fatal_error": fatal, **session,
            })
            if fatal:
                raise SystemExit(f"Stopped Jev on {fatal}; attempted requests remain in the ledger.")
    print(f"{out}: {len(seen) + committed}/{len(rows)} complete")


def execute(args, spec, out, remaining, seen, rows, predictions, ledger, first_backend, first_load_ms):
    lock = threading.Lock()
    stop = threading.Event()
    thread = threading.local()
    fatal = None
    first_available = [first_backend]
    event_log = models.event_logger(ledger, "evaluation", spec, args.subset)

    def audit(row, event):
        nonlocal fatal
        with lock:
            if event["event"] == "start" and stop.is_set():
                raise StopWork
            event_log(row, event)
            if event["event"] == "finish" and event["error_type"] in FATAL_ERRORS:
                fatal = fatal or event["error_type"]
                stop.set()

    def infer(row):
        if stop.is_set():
            return False
        if not hasattr(thread, "backend"):
            with lock:
                if first_available:
                    thread.backend = first_available.pop()
                    load_ms = first_load_ms
                else:
                    started = time.perf_counter()
                    thread.backend = models.make_model(spec)
                    load_ms = 1000 * (time.perf_counter() - started)
                models.append_line(ledger, {
                    "event": "load", "model": spec["name"],
                    "elapsed_ms": load_ms, "started_utc": models.now(),
                })
        try:
            prediction = thread.backend.run(row, args.subset, audit)
        except StopWork:
            return False
        with lock:
            models.append_line(predictions, prediction)
        return True

    next_rows = iter(remaining)
    count = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        active = {pool.submit(infer, row) for row in islice(next_rows, args.workers)}
        try:
            while active:
                done, active = wait(active, return_when=FIRST_COMPLETED)
                previous = count
                count += sum(future.result() for future in done)
                if count // 100 > previous // 100:
                    print(f"{out.name}: {len(seen) + count}/{len(rows)}", flush=True)
                if not stop.is_set():
                    active.update(pool.submit(infer, row) for row in islice(next_rows, len(done)))
        except BaseException:
            stop.set()
            raise
    return count, fatal


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("configs/models.json"))
    parser.add_argument("--data", type=Path, default=Path("data/processed"))
    parser.add_argument("--predictions", type=Path, default=Path("predictions"))
    parser.add_argument("--subset", choices=models.SUBSETS, required=True)
    parser.add_argument("--freeze", type=Path)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--limit", type=int)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
