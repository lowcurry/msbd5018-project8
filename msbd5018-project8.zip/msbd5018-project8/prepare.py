"""Create the VitaminC-real data and independent, unlabeled review packets."""

import argparse
import csv
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from difflib import SequenceMatcher
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import random
import re
from secrets import token_hex
from shutil import rmtree
import tempfile
import unicodedata
from urllib.request import urlopen
import zipfile


LABELS = ("S", "C", "I")
LABEL_MAP = {"SUPPORTS": "S", "REFUTES": "C", "NOT ENOUGH INFO": "I"}
SEED = 42
DEFAULT_MAX_BYTES = 900
SPLITS = ("train", "dev", "test")
SIZES = {"train": 200, "calibration": 2_000, "selection": 2_000, "test": 5_000}
AUDIT_QUOTAS = {"S": 150, "C": 150, "I": 300}
AXES = ("number", "time", "entity", "negation")
HF_REVISION = "be6febb761b0b2807687e61e0b5282e459df2fa0"
HF_ROOT = f"https://huggingface.co/datasets/tals/vitaminc/resolve/{HF_REVISION}"
HF_HASHES = {
    "train": "7461c6fd1a13459590317c5ccdc8651dd2daf7c1ad8ae4b10ccd88d164fccd5a",
    "dev": "544934677f5d133873e6d38f4557f8966f4efa5d3d70874ffe6913f2091b86b5",
    "test": "7ad1808dbc30c62e0a1427a53022d0dfaff668a1fde3c4b612a2d266edd753ad",
}
AUTHOR_ZIP = "https://github.com/TalSchuster/talschuster.github.io/raw/master/static/vitaminc.zip"
ARTICLE = "https://aclanthology.org/2021.naacl-main.52/"
DATA_LICENSE = "https://github.com/TalSchuster/VitaminC/blob/main/DATA_LICENSE"


def sha_file(path):
    with path.open("rb") as file:
        return sha256_stream(file)


def sha256_stream(file):
    digest = sha256()
    for chunk in iter(lambda: file.read(1024 * 1024), b""):
        digest.update(chunk)
    return digest.hexdigest()


def norm(text):
    return " ".join(unicodedata.normalize("NFKC", text).casefold().split())


def page_key(page):
    return norm(page.replace("_", " "))


def hash_text(claim, passage):
    encoded = json.dumps([claim, passage], ensure_ascii=False, separators=(",", ":"))
    return sha256(encoded.encode("utf-8")).hexdigest()


def total_bytes(claim, passage):
    return len(claim.encode("utf-8")) + len(passage.encode("utf-8"))


@dataclass(frozen=True)
class Row:
    id: str
    source_split: str
    claim: str
    passage: str
    label: str
    page: str
    case_id: str
    revision: str

    def keys(self):
        # Group by any matching identifier. The revision ID is globally unique.
        return {
            "page": page_key(self.page),
            "claim": norm(self.claim),
            "pair": hash_text(norm(self.claim), norm(self.passage)),
            "case_id": self.case_id,
            "revision": self.revision,
            "id": self.id,
        }

    def model_input(self):
        return {
            "id": self.id,
            "claim": self.claim,
            "passage": self.passage,
            "text_hash": hash_text(self.claim, self.passage),
        }


def write_json(path, value):
    with path.open("w", encoding="utf-8") as file:
        json.dump(value, file, ensure_ascii=False, indent=2, sort_keys=True)
        file.write("\n")


def write_jsonl(path, rows):
    with path.open("w", encoding="utf-8") as file:
        for row in rows:
            file.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_csv(path, fields, rows):
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def download_source(folder):
    folder.mkdir(parents=True, exist_ok=True)
    for split in SPLITS:
        path = folder / f"{split}.jsonl"
        if path.exists() and sha_file(path) == HF_HASHES[split]:
            continue
        part = path.with_suffix(".jsonl.part")
        with urlopen(f"{HF_ROOT}/{path.name}", timeout=90) as response, part.open("wb") as file:
            for chunk in iter(lambda: response.read(1024 * 1024), b""):
                file.write(chunk)
        if sha_file(part) != HF_HASHES[split]:
            raise ValueError(f"Hash mismatch for {part}")
        part.replace(path)


def source_records(source, split, provenance):
    filename = f"{split}.jsonl"
    if source.is_dir():
        path = source / filename
        digest = sha_file(path)
        provenance[split] = {"file": filename, "sha256": digest}
        if digest == HF_HASHES[split]:
            provenance[split]["url"] = f"{HF_ROOT}/{filename}"
        with path.open("rb") as file:
            yield from file
        return
    with zipfile.ZipFile(source) as archive:
        members = [name for name in archive.namelist() if Path(name).name == filename]
        if len(members) != 1:
            raise ValueError(f"Expected one {filename} in archive, got {members}")
        with archive.open(members[0]) as file:
            digest = sha256_stream(file)
        provenance[split] = {"file": members[0], "sha256": digest}
        with archive.open(members[0]) as file:
            yield from file


def parse_source(source, provenance, log):
    rows = {split: [] for split in SPLITS}
    source_counts = {split: Counter() for split in SPLITS}
    for split in SPLITS:
        for line_num, line in enumerate(source_records(source, split, provenance), 1):
            if not line.strip():
                continue
            item = json.loads(line)
            kind = item.get("revision_type") or "missing"
            source_counts[split][kind] += 1
            row = Row(
                id=item.get("unique_id") or "",
                source_split=split,
                claim=item.get("claim") or "",
                passage=item.get("evidence") or "",
                label=LABEL_MAP.get(item.get("label"), ""),
                page=item.get("page") or "",
                case_id=item.get("case_id") or "",
                revision=str(item.get("wiki_revision_id") or ""),
            )
            if kind != "real":
                log(row, f"revision_type_{kind}", line_num)
                continue
            if not all([row.id, norm(row.claim), norm(row.passage), row.label, norm(row.page),
                        row.case_id, row.revision]):
                log(row, "missing_required_field", line_num)
                continue
            rows[split].append(row)
    return rows, source_counts


def pilot_pages(path, test, no_prior_test_exposure=False):
    if path is None:
        status = "confirmed_no_test_exposure" if no_prior_test_exposure else "prior_exposure_unconfirmed"
        return set(), {"status": status}
    ids = {row.id: page_key(row.page) for row in test}
    valid_pages = set(ids.values())
    blocked = set()
    with path.open(newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)
        if not reader.fieldnames or not {"id", "page"} & set(reader.fieldnames):
            raise ValueError("Pilot CSV must include id and/or page")
        for item in reader:
            raw_id = (item.get("id") or "").strip()
            raw_page = page_key(item.get("page") or "")
            if not raw_id and not raw_page:
                raise ValueError("Blank entry in pilot CSV")
            if raw_id and raw_id not in ids:
                raise ValueError(f"Unknown official real test pilot ID: {raw_id}")
            if raw_page and raw_page not in valid_pages:
                raise ValueError(f"Unknown official real test pilot page: {raw_page}")
            if raw_id and raw_page and ids[raw_id] != raw_page:
                raise ValueError(f"Pilot ID/page mismatch for {raw_id}")
            blocked.add(raw_page or ids[raw_id])
    if not blocked:
        raise ValueError("Pilot CSV is empty. An empty file does not establish prior exposure.")
    return blocked, {"status": "listed_test_pages_excluded", "sha256": sha_file(path),
                     "excluded_pages": len(blocked)}


def eligible_rows(rows, blocked_pages, max_bytes, log):
    previous = defaultdict(set)
    eligible = {}
    all_ids = Counter(row.id for values in rows.values() for row in values)
    all_pair_labels = defaultdict(set)
    for values in rows.values():
        for row in values:
            all_pair_labels[(norm(row.claim), norm(row.passage))].add(row.label)

    for split in SPLITS:
        kept = []
        current = defaultdict(set)
        seen_pairs = set()
        for row in rows[split]:
            keys = row.keys()
            matches = [name for name, key in keys.items() if key and key in previous[name]]
            for name, key in keys.items():
                if key:
                    current[name].add(key)

            if all_ids[row.id] > 1:
                log(row, "duplicate_id")
            elif len(all_pair_labels[(norm(row.claim), norm(row.passage))]) > 1:
                log(row, "conflicting_labels")
            elif split == "test" and keys["page"] in blocked_pages:
                log(row, "pilot_page")
            elif matches:
                log(row, "cross_split_" + "+".join(matches))
            elif total_bytes(row.claim, row.passage) > max_bytes:
                log(row, "common_byte_limit")
            elif keys["pair"] in seen_pairs:
                log(row, "duplicate_pair")
            else:
                kept.append(row)
                seen_pairs.add(keys["pair"])

        eligible[split] = kept
        for name, values in current.items():
            previous[name].update(values)
    return eligible


def partition_dev(rows):
    """Keep all connected page/claim/revision components on the same dev side."""
    parent = list(range(len(rows)))

    def find(index):
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    owners = {}
    for index, row in enumerate(rows):
        for name, value in row.keys().items():
            first = owners.setdefault((name, value), index)
            parent[find(index)] = find(first)

    components = defaultdict(list)
    for index, row in enumerate(rows):
        components[find(index)].append(row)
    groups = list(components.values())
    random.Random(SEED).shuffle(groups)
    groups.sort(key=len, reverse=True)

    pools = ([], [])
    for group in groups:
        target = min(pools, key=len)
        target.extend(group)
    return pools, len(groups)


def stratified(rows, total):
    grouped = {label: sorted((row for row in rows if row.label == label), key=lambda r: r.id)
               for label in LABELS}
    size = len(rows)
    if size < total:
        raise ValueError(f"Only {size} eligible candidates for {total} requested pairs")
    quotient = {label: divmod(total * len(grouped[label]), size) for label in LABELS}
    quotas = {label: quotient[label][0] for label in LABELS}
    remainders = sorted(LABELS, key=lambda label: -quotient[label][1])
    for label in remainders[:total - sum(quotas.values())]:
        quotas[label] += 1
    rng = random.Random(SEED)
    sample = [row for label in LABELS for row in rng.sample(grouped[label], quotas[label])]
    rng.shuffle(sample)
    return sample


def summary(rows):
    counts = Counter(row.label for row in rows)
    pages = Counter(page_key(row.page) for row in rows)
    return {
        "n": len(rows),
        "classes": {label: counts[label] for label in LABELS},
        "unique_pages": len(pages),
        "max_rows_per_page": max(pages.values(), default=0),
        "longest_pair_bytes": max((total_bytes(row.claim, row.passage) for row in rows), default=0),
    }


def check_split_isolation(subsets):
    preceding = defaultdict(set)
    for subset, rows in subsets.items():
        current = defaultdict(set)
        for row in rows:
            for name, key in row.keys().items():
                if key and key in preceding[name]:
                    raise ValueError(f"Leaked {name} into {subset}: {key}")
                if key:
                    current[name].add(key)
        for name, values in current.items():
            preceding[name].update(values)


def write_audit(root, train, test):
    rng = random.Random(SEED)
    selections = []
    totals = Counter(row.label for row in test)
    for label, quota in AUDIT_QUOTAS.items():
        eligible = sorted((row for row in test if row.label == label), key=lambda row: row.id)
        if len(eligible) < quota:
            raise ValueError(f"Audit needs {quota} {label} rows; only {len(eligible)} available")
        selections.extend(rng.sample(eligible, quota))
    rng.shuffle(selections)
    blind = []
    mapping = []
    for row in selections:
        blind_id = token_hex(12)
        blind.append({"blind_id": blind_id, "claim": row.claim, "passage": row.passage})
        mapping.append({"blind_id": blind_id, "id": row.id, "original_label": row.label,
                        "weight": totals[row.label] / AUDIT_QUOTAS[row.label]})
    write_jsonl(root / "audit/audit_blind.jsonl", blind)
    write_csv(root / "restricted/audit_mapping.csv",
              ["blind_id", "id", "original_label", "weight"], mapping)
    practice = rng.sample(train, 40)
    write_jsonl(root / "audit/audit_training.jsonl", [row.model_input() for row in practice])
    write_csv(root / "restricted/audit_training_gold.csv", ["id", "original_label"],
              [{"id": row.id, "original_label": row.label} for row in practice])


NUMBER = re.compile(r"^[+-]?\d[\d,.%]*$")
YEAR = re.compile(r"^(?:1[0-9]{3}|20[0-9]{2}|21[0-9]{2})$")
NEGATION = {"not", "no", "never", "neither", "nor", "without", "none", "n't"}
MONTHS = set(("january february march april may june july august september october "
              "november december").split())


def edit_axis(before, after):
    left = before.split()
    right = after.split()
    changes = [edit for edit in SequenceMatcher(None, left, right, autojunk=False).get_opcodes()
               if edit[0] != "equal"]
    if len(changes) != 1:
        return None
    _, i, j, k, m = changes[0]
    old, new = left[i:j], right[k:m]
    pieces = [word.strip(",.:()[]").casefold() for word in old + new]
    if not pieces or len(pieces) > 6:
        return None
    if all(piece in NEGATION for piece in pieces):
        return "negation"
    if not old or not new:
        return None
    if all(YEAR.fullmatch(piece) or piece in MONTHS or NUMBER.fullmatch(piece) for piece in pieces):
        if any(YEAR.fullmatch(piece) or piece in MONTHS for piece in pieces):
            return "time"
        return "number"
    if all(word[:1].isupper() and word.strip(".-").isalpha() for word in old + new):
        if i and k and all(piece not in NEGATION for piece in pieces):
            return "entity"
    return None


def natural_groups(rows):
    cases = defaultdict(list)
    for row in rows:
        cases[row.case_id].append(row)
    for case_id in sorted(cases):
        members = sorted(cases[case_id], key=lambda row: row.id)
        for first, second in combinations(members, 2):
            before, after = (first, second) if first.label == "S" else (second, first)
            if before.label != "S" or after.label == "S":
                continue
            if before.claim == after.claim:
                field = "passage"
            elif before.passage == after.passage:
                field = "claim"
            else:
                continue
            axis = edit_axis(getattr(before, field), getattr(after, field))
            if axis is not None:
                yield axis, before, after, field


def constructed_claims(axis, row):
    """Generate single-edit proposals; reviewer labels remain authoritative."""
    if axis == "negation":
        words = set(re.findall(r"[A-Za-z']+", row.claim.casefold()))
        if words & NEGATION or any(word.endswith("n't") for word in words):
            return
        match = re.search(r"\b(?:was|were|is|are) (?=[A-Za-z])", row.claim)
        if match:
            stop = match.end()
            yield row.claim[:stop] + "not " + row.claim[stop:], "C"
        return

    if axis == "entity":
        for match in re.finditer(r"\b[A-Z][a-z]+(?: [A-Z][a-z]+){1,3}\b", row.claim):
            if match.start() and match.group() in row.passage:
                replacement = "Rosendale" if "Rosendale" not in row.claim + row.passage else "Kirkwood"
                yield row.claim[:match.start()] + replacement + row.claim[match.end():], "I"
        return

    for match in re.finditer(r"(?<![\w.,])\d+(?:,\d{3})*(?![\w]|[.,]\d)", row.claim):
        value = match.group()
        if not re.search(rf"(?<![\w.,]){re.escape(value)}(?![\w]|[.,]\d)", row.passage):
            continue
        is_year = YEAR.fullmatch(value) is not None
        if is_year != (axis == "time"):
            continue
        if axis == "number" and re.search(r"\b(?:about|around|least|most|over|under|than)\b",
                                          row.claim.casefold()):
            continue
        changed = int(value.replace(",", "")) + (1 if is_year else 3)
        replacement = f"{changed:,}" if "," in value else str(changed)
        if re.search(rf"(?<![\w.,]){re.escape(replacement)}(?![\w]|[.,]\d)", row.passage):
            continue
        yield row.claim[:match.start()] + replacement + row.claim[match.end():], "C"


def write_diagnostics(root, holdout, selected, max_bytes):
    chosen = defaultdict(list)
    used_cases = set()
    # Official test remainder. No selected row, case, pair, claim or revision can be reused.
    blocked = defaultdict(set)
    for row in selected:
        for name, key in row.keys().items():
            if name != "page":
                blocked[name].add(key)

    def independent(row):
        return all(key not in blocked[name] for name, key in row.keys().items() if name != "page")

    eligible = [row for row in holdout if independent(row)]
    candidates = list(natural_groups(eligible))
    rng = random.Random(SEED)
    rng.shuffle(candidates)
    for axis, before, after, field in candidates:
        if len(chosen[axis]) >= 50 or before.case_id in used_cases:
            continue
        chosen[axis].append(("natural", before, after, field))
        used_cases.add(before.case_id)

    supported = sorted((row for row in eligible if row.label == "S"), key=lambda row: row.id)
    rng.shuffle(supported)
    existing_claims = {norm(row.claim) for row in eligible} | blocked["claim"]
    for axis in AXES:
        for before in supported:
            if len(chosen[axis]) == 50:
                break
            if before.case_id in used_cases:
                continue
            modification = next(((claim, label) for claim, label in constructed_claims(axis, before)
                                 if norm(claim) not in existing_claims and
                                 total_bytes(claim, before.passage) <= max_bytes), None)
            if modification is None:
                continue
            claim, label = modification
            after = Row(f"{before.id}~{axis}", before.source_split, claim, before.passage, label,
                        before.page, before.case_id, before.revision)
            chosen[axis].append(("constructed", before, after, "claim"))
            existing_claims.add(norm(claim))
            used_cases.add(before.case_id)

    review, inputs, labels = [], [], []
    breakdown = {}
    for axis in AXES:
        groups = chosen[axis]
        breakdown[axis] = dict(Counter(group[0] for group in groups))
        for n, (kind, before, after, field) in enumerate(groups, 1):
            group_id = f"{axis}-{n:02d}"
            pair = [before.model_input(), after.model_input()]
            inputs.extend(pair)
            review.append({"group_id": group_id, "axis": axis, "source_kind": kind, "pairs": pair})
            for row, role in zip((before, after), ("base", "edited")):
                labels.append({"id": row.id, "group_id": group_id, "axis": axis, "source_kind": kind,
                               "expected_label": row.label, "expected_change": f"{before.label}>{after.label}",
                               "edit": field, "role": role, "page": row.page, "case_id": row.case_id,
                               "revision": row.revision, "verification": "pending_two_human_reviews"})

    write_jsonl(root / "processed/inputs_diagnostics.jsonl", inputs)
    write_jsonl(root / "diagnostics/diagnostic_review.jsonl", review)
    write_csv(root / "restricted/diagnostic_candidates.csv",
              ["id", "group_id", "axis", "source_kind", "expected_label", "expected_change",
               "edit", "role", "page", "case_id", "revision", "verification"], labels)
    return {"groups": len(review), "pairs": len(inputs), "by_axis": breakdown,
            "shortfall": {axis: 50 - len(chosen[axis]) for axis in AXES},
            "label_status": "pending_two_human_reviews",
            "independence": "Held out by row ID, normalized claim/pair, case and revision. "
                            "Different revisions of the same article can occur in the main test."}


def create_data(source, pilot, output, max_bytes, source_url=None, no_prior_test_exposure=False):
    output.mkdir()
    for name in ("processed", "restricted", "audit", "diagnostics"):
        (output / name).mkdir(mode=0o700 if name == "restricted" else 0o755)
    provenance = {}
    if source.is_file():
        provenance["archive"] = {"file": source.name, "sha256": sha_file(source),
                                 "url": source_url}
    reasons = Counter()
    with (output / "processed/exclusions.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["source_split", "source_line", "id", "page", "rule"])

        def log(row, reason, line_number=""):
            reasons[(row.source_split, reason)] += 1
            writer.writerow([row.source_split, line_number, row.id, row.page, reason])

        rows, raw_counts = parse_source(source, provenance, log)
        blocked, pilot_status = pilot_pages(pilot, rows["test"], no_prior_test_exposure)
        pool = eligible_rows(rows, blocked, max_bytes, log)

    dev_pools, components = partition_dev(pool["dev"])
    candidates = {"train": pool["train"], "calibration": dev_pools[0],
                  "selection": dev_pools[1], "test": pool["test"]}
    sampled = {name: stratified(candidates[name], count) for name, count in SIZES.items()}
    check_split_isolation(sampled)
    selected_rows = [row for subset in sampled.values() for row in subset]
    for subset, records in sampled.items():
        write_jsonl(output / f"processed/inputs_{subset}.jsonl", [row.model_input() for row in records])

    manifest = []
    for subset, records in sampled.items():
        for row in records:
            manifest.append({"id": row.id, "source_split": row.source_split, "subset": subset,
                             "page": row.page, "case_id": row.case_id, "revision": row.revision,
                             "text_hash": hash_text(row.claim, row.passage),
                             "length_bytes": total_bytes(row.claim, row.passage)})
    write_csv(output / "processed/manifest.csv",
              ["id", "source_split", "subset", "page", "case_id", "revision", "text_hash",
               "length_bytes"], manifest)
    write_csv(output / "restricted/gold_original.csv", ["id", "original_label"],
              [{"id": row.id, "original_label": row.label} for row in selected_rows])
    write_audit(output, sampled["train"], sampled["test"])
    diagnostics = write_diagnostics(output, pool["test"], selected_rows, max_bytes)

    write_json(output / "processed/sampling_report.json", {
        "raw_counts": raw_counts,
        "candidates": {name: summary(records) for name, records in candidates.items()},
        "subsets": {name: summary(records) for name, records in sampled.items()},
        "dev_partition_components": components,
        "exclusions": {split: {rule: n for (source, rule), n in reasons.items() if split == source}
                       for split in SPLITS},
        "pilot": pilot_status,
        "diagnostics": diagnostics,
        "audit": {"expected_rows_per_reviewer": 600, "by_original_label": AUDIT_QUOTAS,
                  "practice_train": 40, "human_labels": "pending"},
    })
    write_json(output / "processed/freeze_manifest.json", {
        "status": "provisional",
        "issues": ["Exact model-tokenizer length preflights and test protocol freeze are pending."] +
                  (["Prior pilot exposure is unconfirmed."]
                   if pilot_status["status"] == "prior_exposure_unconfirmed" else []),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source": provenance,
        "source_project": "https://github.com/TalSchuster/VitaminC",
        "source_author_download": AUTHOR_ZIP,
        "dataset_paper": ARTICLE,
        "dataset_license": DATA_LICENSE,
        "pilot": pilot_status,
        "seed": SEED,
        "sampling": "Without replacement; largest-remainder class quotas with S/C/I tie order.",
        "length": {"combined_utf8_max_bytes": max_bytes, "silent_truncation": False,
                   "default_basis": "A development selection pair of 982 bytes reached 521 FLAN-T5 "
                                    "tokens with the rubric (512-token limit). The shared 900-byte "
                                    "gate was fixed before test inference using length only."},
        "integrity": "Source train > dev > test precedence by normalized article, claim, pair, "
                     "case, revision and row ID. All metadata-valid real rows supply prior keys. "
                     "Dev connected components by the same fields are assigned greedily by size.",
        "files": {str(file.relative_to(output)): sha_file(file)
                  for file in sorted(output.rglob("*")) if file.is_file()},
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path, help="VitaminC author ZIP or JSONL directory")
    parser.add_argument("--download", action="store_true", help="Download verified pinned HF files to --source")
    parser.add_argument("--source-url", help="Download URL if using a local author ZIP")
    parser.add_argument("--output", type=Path, default=Path("data"))
    pilot = parser.add_mutually_exclusive_group()
    pilot.add_argument("--pilot", type=Path, help="CSV of known official test exposure (id/page)")
    pilot.add_argument("--no-prior-test-exposure", action="store_true",
                       help="Use only after all group members confirm no prior official test exposure")
    parser.add_argument("--max-bytes", type=int, default=DEFAULT_MAX_BYTES,
                        help="Provisional combined claim and passage byte limit")
    args = parser.parse_args()
    if args.max_bytes <= 0:
        parser.error("--max-bytes must be positive")
    if args.output.exists():
        parser.error("--output must be a new directory")
    if args.download:
        download_source(args.source)
    if not args.source.exists():
        parser.error("--source does not exist; supply the author archive or use --download")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".vitaminc-", dir=args.output.parent))
    try:
        create_data(args.source, args.pilot, stage / "data", args.max_bytes, args.source_url,
                    args.no_prior_test_exposure)
        (stage / "data").rename(args.output)
    finally:
        rmtree(stage)
    print(f"Wrote provisional VitaminC-real manifests to {args.output}")


if __name__ == "__main__":
    main()
