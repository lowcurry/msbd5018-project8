# Project 8 independent review packets

The coordinator keeps the individual CSVs in a separate working directory and distributes them privately. This repository contains the workflow and rubric.

The team confirmed that it had no prior exposure to the official test set. The prepared sample and the anonymous reviewer IDs were verified against the previous packets.

| Stage | Reviewer A | Reviewer B | Rows per reviewer |
|---|---|---|---:|
| Main-test label audit | audit_A.csv | audit_B.csv | 600 |
| Diagnostic member labels | diagnostics_A.csv | diagnostics_B.csv | 400 |
| Diagnostic edit checks | diagnostic_groups_A.csv | diagnostic_groups_B.csv | 200 |

The coordinator should give each reviewer only their individual sheet and the [annotation rubric](../ANNOTATION.md). Share the paired diagnostic edit sheet after the independent member labels have been returned. Keep the source-label mapping and reviewer responses private.

Return completed sheets to the coordinator with the assigned IDs and text intact. The coordinator prepares separate blind adjudication material for disagreements, ambiguity, and exposure using `human.py adjudicate`.
