"""Freeze a development policy and reproduce analysis from complete prediction caches."""

import argparse
import csv
import hashlib
import json
import math
import platform
import random
import statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


LABELS = ("S", "C", "I")
MODELS = ("jev", "nli", "llm")
FAIL = len(LABELS)
LABEL_INDEX = dict(zip(LABELS, range(FAIL)))
COUNTS = {"train": 200, "calibration": 2000, "selection": 2000, "test": 5000}
GRID = (1 / 3, .50, .60, .70, .75, .80, .85, .90, .925, .95, .975, .99, 1.)
BUDGET_PERCENT = (10, 25, 50, 75)
EPS = 1e-12
PROB_TOL = 1e-5
MARGIN = .02
T_BOUNDS = (.01, 100.)
BUDGET_SEEDS = tuple(range(18001, 18021))
MATCHED_SEEDS = tuple(range(19001, 19021))
BOOTSTRAP_SEED = 20261106
BOOTSTRAP_REPLICATES = 5000
TIE_PREFIX = "budget-tie-v1|"


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def read_jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write_json(path, result):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows, empty_fields=()):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys([*empty_fields, *(field for row in rows for field in row)]))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def data_path(directory, relative, filename):
    path = directory / relative / filename
    return path if path.is_file() else directory / filename


def unique(rows, field, origin):
    result = {}
    for row in rows:
        key = row.get(field)
        if not key or key in result:
            raise ValueError(f"{origin}: missing or duplicate {field} {key!r}")
        result[key] = row
    return result


def choose_manifest(manifest, subset, expected):
    rows = sorted((row for row in manifest if row["subset"] == subset), key=lambda row: row["id"])
    if len(rows) != expected:
        raise ValueError(f"{subset}: expected {expected} manifest rows, found {len(rows)}")
    return rows


def read_gold(path, rows):
    ids = {row["id"] for row in rows}
    # This loader only exposes labels for the subset that the current phase can score.
    allowed = unique([row for row in read_csv(path) if row["id"] in ids], "id", path)
    if set(allowed) != ids:
        raise ValueError(f"{path}: missing {len(ids - set(allowed))} requested gold labels")
    return np.array([LABEL_INDEX[allowed[row["id"]]["original_label"]] for row in rows], dtype=np.int8)


def probability(row, model):
    flat = [row.get(f"p_{label}") for label in LABELS]
    if all(item is None for item in flat):
        nested = row.get("probabilities") or {}
        flat = [nested.get(label) for label in LABELS]
    if any(isinstance(item, bool) or not isinstance(item, (int, float)) for item in flat):
        return None
    p = np.array(flat, dtype=float)
    if not np.all(np.isfinite(p)) or np.any(p < 0) or np.any(p > 1) or abs(p.sum() - 1) > PROB_TOL:
        return None
    pred = row.get("pred_label")
    if pred in LABEL_INDEX and p[LABEL_INDEX[pred]] < p.max() - EPS:
        raise ValueError(f"{model}: probability argmax disagrees with pred_label for {row['id']}")
    return p / p.sum()


def load_predictions(directory, subset, rows, expected_configs=None):
    paths = {model: directory / f"{model}_{subset}.jsonl" for model in MODELS}
    outputs = {}
    for model, path in paths.items():
        records = unique(read_jsonl(path), "id", path)
        if set(records) != {row["id"] for row in rows}:
            raise ValueError(f"{path}: ID set differs from the {subset} manifest")
        values = []
        probs = np.full((len(rows), FAIL), np.nan)
        hashes = set()
        for i, row in enumerate(rows):
            rec = records[row["id"]]
            if rec["subset"] != subset or rec["text_hash"] != row["text_hash"]:
                raise ValueError(f"{path}: stale or mismatched prediction for {row['id']}")
            config = rec["config_hash"]
            if not isinstance(config, str) or not config:
                raise ValueError(f"{path}: empty config_hash for {row['id']}")
            hashes.add(config)
            label = rec.get("pred_label")
            if label is not None and label not in LABEL_INDEX:
                raise ValueError(f"{path}: invalid label {label!r} for {row['id']}")
            p = probability(rec, model) if label is not None else None
            if p is not None:
                probs[i] = p
            if model != "llm" and p is None:
                label = None
            values.append(LABEL_INDEX.get(label, FAIL))
        if len(hashes) != 1:
            raise ValueError(f"{path}: prediction configuration changed within one subset")
        config = hashes.pop()
        if expected_configs is not None and config != expected_configs[model]:
            raise ValueError(f"{path}: prediction configuration differs from the frozen development configuration")
        outputs[model] = {
            "pred": np.asarray(values, dtype=np.int8),
            "probs": probs,
            "config_hash": config,
            "cache_sha256": digest(path),
        }
    return outputs


def ratio(numerator, denominator):
    return float(numerator / denominator) if denominator else None


def confusion(gold, pred, weights=None):
    return np.bincount(
        gold.astype(int) * (FAIL + 1) + pred,
        weights=weights,
        minlength=FAIL * (FAIL + 1),
    ).reshape((FAIL, FAIL + 1))


def f1_of(matrix):
    row = matrix.sum(axis=-1)
    col = matrix[..., :FAIL].sum(axis=-2)
    true = np.diagonal(matrix[..., :FAIL], axis1=-2, axis2=-1)
    denom = row + col
    return np.divide(2 * true, denom, out=np.zeros_like(denom, dtype=float), where=denom != 0)


def scores(gold, pred, weights=None):
    matrix = confusion(gold, pred, weights)
    n = matrix.sum()
    f1 = f1_of(matrix)
    result = {
        "n": len(gold),
        "weighted_n": float(n),
        "accuracy": ratio(np.trace(matrix), n),
        "macro_f1": float(f1.mean()) if n else None,
        "failures": int((pred == FAIL).sum()),
        "failure_rate": ratio(matrix[:, FAIL].sum(), n),
        "false_support_numerator": float(matrix[1:, 0].sum()),
        "false_support_denominator": float(matrix[1:].sum()),
        "false_support_rate": ratio(matrix[1:, 0].sum(), matrix[1:].sum()),
        "support_precision_numerator": float(matrix[0, 0]),
        "support_precision_denominator": float(matrix[:, 0].sum()),
        "support_precision": ratio(matrix[0, 0], matrix[:, 0].sum()),
    }
    for i, label in enumerate(LABELS):
        result[f"n_gold_{label}"] = float(matrix[i].sum())
        result[f"precision_{label}"] = ratio(matrix[i, i], matrix[:, i].sum()) or 0.
        result[f"recall_{label}"] = ratio(matrix[i, i], matrix[i].sum()) or 0.
        result[f"f1_{label}"] = float(f1[i])
        for j, target in enumerate((*LABELS, "failed")):
            result[f"cm_{label}_{target}"] = float(matrix[i, j])
    return result


def softmax(logits):
    values = np.exp(logits - logits.max(axis=1, keepdims=True))
    return values / values.sum(axis=1, keepdims=True)


def valid(probs):
    return np.all(np.isfinite(probs), axis=1)


def fit_temperature(probs, gold):
    mask = valid(probs)
    if not np.any(mask):
        return None
    logp = np.log(np.maximum(probs[mask], EPS))
    gold = gold[mask]
    observed = logp[np.arange(len(logp)), gold]
    if np.all(np.ptp(logp, axis=1) == 0):
        return 1.0
    # NLL is convex in inverse temperature. Bisect its derivative on frozen bounds.
    lo, hi = 1 / T_BOUNDS[1], 1 / T_BOUNDS[0]
    for _ in range(64):
        beta = (lo + hi) / 2
        derivative = ((softmax(beta * logp) * logp).sum(axis=1) - observed).mean()
        if derivative > 0:
            hi = beta
        else:
            lo = beta
    return float(2 / (lo + hi))


def calibrate(probs, temperature):
    if temperature is None:
        return probs.copy()
    mask = valid(probs)
    result = probs.copy()
    result[mask] = softmax(np.log(np.maximum(probs[mask], EPS)) / temperature)
    # Clipping may tie tiny values but cannot change the maximum of a valid 3-class distribution.
    raw_argmax = probs[mask].argmax(axis=1)
    if np.any(result[mask].max(axis=1) - result[mask][np.arange(len(raw_argmax)), raw_argmax] > EPS):
        raise ValueError("temperature scaling changed the distribution argmax")
    return result


def bins(confidence):
    return np.minimum((confidence * 10).astype(int), 9)


def probability_metrics(gold, pred, probs, weights=None):
    mask = valid(probs)
    n = int(mask.sum())
    y, p = gold[mask], probs[mask]
    w = np.ones(n) if weights is None else np.asarray(weights)[mask]
    weight = w.sum()
    result = {"probability_n": n, "probability_weighted_n": float(weight), "nll": None, "brier": None, "ece": None}
    if not n:
        return result, []
    confidence = p.max(axis=1)
    correct = pred[mask] == y
    partitions = bins(confidence)
    ece = 0.
    reliability = []
    for i in range(10):
        take = partitions == i
        bin_weight = w[take].sum()
        accuracy = ratio(np.dot(w[take], correct[take]), bin_weight)
        mean = ratio(np.dot(w[take], confidence[take]), bin_weight)
        if bin_weight:
            ece += bin_weight * abs(accuracy - mean) / weight
        reliability.append({"bin": i, "lower": i / 10, "upper": (i + 1) / 10, "n": int(take.sum()),
                            "weighted_n": float(bin_weight), "accuracy": accuracy, "mean_confidence": mean})
    target = np.eye(FAIL)[y]
    losses = -np.log(np.maximum(p[np.arange(n), y], EPS))
    result.update(nll=float(np.dot(w, losses) / weight),
                  brier=float(np.dot(w, np.square(p - target).sum(axis=1)) / weight), ece=float(ece))
    return result, reliability


def threshold_mask(probs, threshold):
    conf = probs.max(axis=1)
    return ~valid(probs) | (np.maximum(conf, 1 / FAIL) < threshold)


def routed(base, fallback, upgrade):
    return np.where(upgrade, fallback, base)


def decomposition(gold, base, fallback, upgrade):
    base_ok = base == gold
    llm_ok = fallback == gold
    m = int(upgrade.sum())
    c_e = int((upgrade & base_ok).sum())
    c_llm = int((upgrade & llm_ok).sum())
    g = int((upgrade & ~base_ok & llm_ok).sum())
    h = int((upgrade & base_ok & ~llm_ok).sum())
    if int((routed(base, fallback, upgrade) == gold).sum() - base_ok.sum()) != g - h:
        raise AssertionError("g/h decomposition does not reconstruct the routed accuracy")
    return {"upgrades": m, "upgrade_rate": ratio(m, len(gold)), "base_correct_on_upgrades": c_e,
            "llm_correct_on_upgrades": c_llm, "base_accuracy_on_upgrades": ratio(c_e, m),
            "llm_accuracy_on_upgrades": ratio(c_llm, m), "g": g, "h": h,
            "accuracy_gain": ratio(g - h, len(gold)), "oracle_gain": ratio(m - c_e, len(gold))}


def scored_route(gold, base, fallback, upgrade):
    return {**scores(gold, routed(base, fallback, upgrade)), **decomposition(gold, base, fallback, upgrade)}


def select_policy(gold, outputs, calibrated):
    grid = []
    policy = {}
    llm = outputs["llm"]["pred"]
    baseline_f1 = scores(gold, llm)["macro_f1"]
    target = baseline_f1 - MARGIN
    for model in MODELS:
        grid.append({"system": f"all-{model}", "mode": "direct_all_llm" if model == "llm" else "single_model",
                     "upgrades": len(gold) if model == "llm" else 0,
                     **scores(gold, outputs[model]["pred"])})
    for model in ("jev", "nli"):
        base = outputs[model]["pred"]
        options = []
        for threshold in GRID:
            upgrade = threshold_mask(calibrated[model], threshold)
            metrics = scored_route(gold, base, llm, upgrade)
            record = {"system": f"{model}-to-llm", "mode": "cascade", "threshold": threshold,
                      "forced_upgrades": int((~valid(calibrated[model])).sum()), **metrics,
                      "selection_floor": target, "meets_floor": metrics["macro_f1"] >= target}
            options.append(record)
        feasible = [row for row in options if row["meets_floor"] and row["upgrades"] < len(gold)]
        chosen = min(feasible, key=lambda row: (row["upgrades"], row["threshold"])) if feasible else None
        for row in options:
            row["selected"] = row is chosen
        grid.extend(options)
        policy[model] = {
            "mode": "cascade" if chosen is not None else "direct_all_llm",
            "threshold": chosen["threshold"] if chosen is not None else None,
            "selection_floor": target,
            "selection_upgrades": chosen["upgrades"] if chosen is not None else len(gold),
            "selection_macro_f1": chosen["macro_f1"] if chosen is not None else baseline_f1,
        }
    return policy, grid


def tie_hash(identifier):
    return hashlib.sha256((TIE_PREFIX + identifier).encode("utf-8")).hexdigest()


def rank(probs, hashes, descending=False):
    confidence = probs.max(axis=1)
    sign = -1 if descending else 1
    return sorted(np.flatnonzero(valid(probs)), key=lambda i: (sign * confidence[i], hashes[i]))


def random_mask(allowed, forced, total, seed):
    result = forced.copy()
    selected = random.Random(seed).sample(list(allowed), total - int(forced.sum()))
    result[selected] = True
    return result


def aggregate_seed_rows(rows, keys):
    skip = {*keys, "seed", "feasible"}
    groups = defaultdict(list)
    for row in rows:
        if row.get("feasible", True):
            groups[tuple(row[key] for key in keys)].append(row)
    result = []
    for key, group in groups.items():
        summary = {**dict(zip(keys, key)), "seeds": len(group)}
        for field in group[0]:
            if field in skip:
                continue
            values = [row[field] for row in group if isinstance(row.get(field), (int, float))]
            if not values:
                continue
            summary[f"{field}_mean"] = statistics.mean(values)
            summary[f"{field}_sd"] = statistics.stdev(values) if len(values) > 1 else None
        result.append(summary)
    return result


def budget_sets(ids, raw, adjusted):
    """Construct upgrade masks without access to gold labels or LLM predictions."""
    hashes = [tie_hash(identifier) for identifier in ids]
    forced = ~valid(raw)
    if not np.array_equal(forced, ~valid(adjusted)):
        raise AssertionError("calibration changed the valid-score subset")
    rankings = {"raw": rank(raw, hashes), "calibrated": rank(adjusted, hashes)}
    f = int(forced.sum())
    n = len(ids)
    for pct in BUDGET_PERCENT:
        total = (pct * n + 99) // 100
        common = {"budget_pct": pct, "target_upgrades": total, "forced_upgrades": f, "feasible": f <= total}
        for method, ordering in rankings.items():
            mask = None
            if f <= total:
                mask = forced.copy()
                mask[ordering[:total - f]] = True
            yield {**common, "method": method, "seed": None}, mask
        allowed = np.flatnonzero(~forced)
        for seed in BUDGET_SEEDS:
            mask = random_mask(allowed, forced, total, seed) if f <= total else None
            yield {**common, "method": "random", "seed": seed}, mask


def budget_outputs(out, rows, outputs, calibrated, gold):
    ids = [row["id"] for row in rows]
    jev = outputs["jev"]
    forced = ~valid(jev["probs"])
    # Materialize routing sets independently before using LLM outputs or gold to score them.
    sets = list(budget_sets(ids, jev["probs"], calibrated["jev"]))
    metrics, routed_ids = [], []
    for config, mask in sets:
        record = {**config, "n": len(ids)}
        if mask is not None:
            if int(mask.sum()) != config["target_upgrades"] or not np.all(mask[forced]):
                raise AssertionError("budget mismatch or missing forced upgrade")
            record.update(scored_route(gold, jev["pred"], outputs["llm"]["pred"], mask))
            routed_ids.extend({**config, "id": ids[i], "forced": bool(forced[i])} for i in np.flatnonzero(mask))
        metrics.append(record)
    write_csv(out / "budget_ablation_metrics.csv", metrics)
    write_csv(out / "budget_routing_ids.csv", routed_ids, ("budget_pct", "method", "seed", "id", "forced"))
    write_csv(out / "budget_random_summary.csv",
              aggregate_seed_rows([row for row in metrics if row["method"] == "random"], ["budget_pct"]),
              ("budget_pct", "seeds"))


def config_manifest():
    return {"temperature_epsilon": EPS, "temperature_bounds": T_BOUNDS, "temperature_bisection_steps": 64,
            "probability_tolerance": PROB_TOL, "threshold_grid": GRID, "margin": MARGIN, "ece_bins": 10,
            "budget_percent": BUDGET_PERCENT, "budget_rule": "ceil(N * pct / 100), including forced upgrades",
            "tie_rule": f"SHA-256 of UTF-8 {TIE_PREFIX!r} + ID, hex ascending",
            "budget_seeds": BUDGET_SEEDS, "matched_seeds": MATCHED_SEEDS,
            "routing_rng": f"random.Random.sample, Python {platform.python_version()}",
            "bootstrap_seed": BOOTSTRAP_SEED, "bootstrap_replicates": BOOTSTRAP_REPLICATES,
            "bootstrap_rng": f"numpy.random.Generator(PCG64), NumPy {np.__version__}",
            "labels": LABELS, "zero_division_f1": 0}


def calibrate_all(outputs, temperatures):
    return {model: calibrate(outputs[model]["probs"], temperatures[model]) for model in MODELS}


def probability_tables(out, outputs, calibrated, gold, weights=None):
    metrics = []
    reliability = []
    for model in MODELS:
        for version, p in (("raw", outputs[model]["probs"]), ("calibrated", calibrated[model])):
            pred = outputs[model]["pred"]
            report, curve = probability_metrics(gold, pred, p, weights)
            metrics.append({"model": model, "score_version": version, "n": len(gold),
                            "failure_rate": ratio(int((pred == FAIL).sum()), len(gold)), **report})
            reliability.extend({"model": model, "score_version": version, **row} for row in curve)
    write_csv(out / "calibration_metrics.csv", metrics)
    write_csv(out / "reliability.csv", reliability, ("model", "score_version", "bin"))


def verify_prepared(directory):
    path = data_path(directory, "processed", "freeze_manifest.json")
    metadata = json.loads(path.read_text(encoding="utf-8"))
    if metadata["pilot"]["status"] not in {"listed_test_pages_excluded", "confirmed_no_test_exposure"}:
        raise ValueError("prior pilot exposure remains unconfirmed; rebuild data with the team's confirmed exposure record")
    # The preparation manifest fingerprints its outputs before development starts.
    for relative, expected in metadata["files"].items():
        file = directory / relative
        if digest(file) != expected:
            raise ValueError(f"{file}: prepared data differ from the recorded version")
    return digest(path)


def verify_preflight(directory, input_hashes, counts, configs):
    hashes = {}
    for subset, expected in input_hashes.items():
        for model in ("nli", "llm"):
            path = directory / f"{model}_{subset}.json"
            preflight = json.loads(path.read_text(encoding="utf-8"))
            if (
                preflight["model"] != model or preflight["subset"] != subset
                or preflight["config_hash"] != configs[model] or preflight["input_sha256"] != expected
                or preflight["n"] != counts[subset] or preflight["oversized_ids"]
                or not 0 < preflight["max_tokens"] <= preflight["max_input_tokens"]
            ):
                raise ValueError(f"{path}: tokenizer preflight is incomplete or mismatched")
            hashes[path.name] = digest(path)
    return hashes


def freeze(args, manifest_path, manifest, gold_path):
    marker = args.out / "protocol_freeze.json"
    if marker.exists():
        raise ValueError(f"{marker}: protocol already frozen; choose a fresh output directory")
    prepared_sha = verify_prepared(args.data)
    for subset in ("test", "diagnostics"):
        if any((args.predictions / f"{model}_{subset}.jsonl").exists() for model in MODELS):
            raise ValueError(f"found formal {subset} cache before protocol freeze")
    cal_rows = choose_manifest(manifest, "calibration", COUNTS["calibration"])
    sel_rows = choose_manifest(manifest, "selection", COUNTS["selection"])
    if {row["page"] for row in cal_rows} & {row["page"] for row in sel_rows}:
        raise ValueError("calibration and selection must be article-disjoint")
    cal = load_predictions(args.predictions, "calibration", cal_rows)
    configs = {model: cal[model]["config_hash"] for model in MODELS}
    sel = load_predictions(args.predictions, "selection", sel_rows, configs)
    for subset, outputs in (("calibration", cal), ("selection", sel)):
        for model, output in outputs.items():
            if np.all(output["pred"] == FAIL):
                raise ValueError(f"{model}: no valid {subset} predictions; check model or access")
    y_cal = read_gold(gold_path, cal_rows)
    y_sel = read_gold(gold_path, sel_rows)
    temperatures = {model: fit_temperature(cal[model]["probs"], y_cal) for model in MODELS}
    adjusted = calibrate_all(sel, temperatures)
    policy, grid = select_policy(y_sel, sel, adjusted)
    extras = [Path(path) for path in args.freeze_file]
    if len({path.name for path in extras}) != len(extras):
        raise ValueError("extra freeze files must have distinct basenames")
    input_hashes = {}
    counts = {**COUNTS, "diagnostics": 400, "efficiency": 100}
    test_rows = {row["id"]: row["text_hash"] for row in choose_manifest(manifest, "test", COUNTS["test"])}
    for subset in (*COUNTS, "diagnostics", "efficiency"):
        path = data_path(args.data, "processed", f"inputs_{subset}.jsonl")
        inputs = unique(read_jsonl(path), "id", path)
        if len(inputs) != counts[subset]:
            raise ValueError(f"{path}: expected {counts[subset]} frozen inputs")
        if subset in COUNTS:
            selected = choose_manifest(manifest, subset, COUNTS[subset])
            expected = {row["id"]: row["text_hash"] for row in selected}
            if {identifier: row["text_hash"] for identifier, row in inputs.items()} != expected:
                raise ValueError(f"{path}: ID/text_hash pairs differ from manifest")
        elif subset == "diagnostics" and inputs.keys() & test_rows.keys():
            raise ValueError("diagnostic inputs share IDs with the main test")
        elif subset == "efficiency" and any(test_rows.get(key) != row["text_hash"] for key, row in inputs.items()):
            raise ValueError("efficiency workload must contain exact copies of frozen test pairs")
        input_hashes[subset] = digest(path)
    efficiency_plan = data_path(args.data, "processed", "efficiency_plan.json")
    efficiency = json.loads(efficiency_plan.read_text(encoding="utf-8"))
    if (efficiency["benchmark_input_sha256"] != input_hashes["efficiency"]
            or efficiency["test_input_sha256"] != input_hashes["test"] or efficiency["repeats"] != 3):
        raise ValueError("efficiency plan does not match the 100 × 3 workload")
    preflight = verify_preflight(args.preflight_dir, input_hashes, counts, configs)
    probability_tables(args.out, cal, calibrate_all(cal, temperatures), y_cal)
    budget_outputs(args.out / "selection", sel_rows, sel, adjusted, y_sel)
    write_json(args.out / "temperatures.json", temperatures)
    write_json(args.out / "routing_policy.json", policy)
    write_csv(args.out / "selection_grid.csv", grid)
    write_json(args.out / "budget_ablation_config.json", config_manifest())
    frozen = {
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "protocol": config_manifest(),
        "temperatures": temperatures,
        "routing_policy": policy,
        "manifest_sha256": digest(manifest_path),
        "prepared_manifest_sha256": prepared_sha,
        "preflight_sha256": preflight,
        "input_sha256": input_hashes,
        "efficiency_plan_sha256": digest(efficiency_plan),
        "config_hashes": configs,
        "evaluate_py_sha256": digest(Path(__file__)),
        "calibration_cache_sha256": {model: cal[model]["cache_sha256"] for model in MODELS},
        "selection_cache_sha256": {model: sel[model]["cache_sha256"] for model in MODELS},
        "development_gold_sha256": {
            subset: hashlib.sha256(y.tobytes()).hexdigest()
            for subset, y in (("calibration", y_cal), ("selection", y_sel))
        },
        "additional_file_sha256": {path.name: digest(path) for path in extras},
    }
    audit_mapping = data_path(args.data, "restricted", "audit_mapping.csv")
    if audit_mapping.is_file():
        frozen["audit_mapping_sha256"] = digest(audit_mapping)
    write_json(marker, frozen)


def make_systems(outputs, calibrated, policy):
    systems = {f"all-{model}": outputs[model]["pred"] for model in MODELS}
    upgrades = {}
    for model in ("jev", "nli"):
        mask = (np.ones(len(systems["all-llm"]), dtype=bool) if policy[model]["mode"] == "direct_all_llm"
                else threshold_mask(calibrated[model], policy[model]["threshold"]))
        upgrades[model] = mask
        systems[f"{model}-to-llm"] = routed(outputs[model]["pred"], outputs["llm"]["pred"], mask)
    return systems, upgrades


def bootstrap(rows, gold, primary, comparator):
    pages = {}
    for i, row in enumerate(rows):
        if not row.get("page"):
            raise ValueError(f"missing article cluster for {row['id']}")
        pages.setdefault(row["page"], []).append(i)
    counts = []
    for ids in pages.values():
        counts.append(np.stack([confusion(gold[ids], pred[ids]) for pred in (primary, comparator)]))
    totals = np.stack(counts).reshape(len(pages), -1)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    probabilities = np.full(len(pages), 1 / len(pages))
    deltas = []
    missing = 0
    for start in range(0, BOOTSTRAP_REPLICATES, 100):
        size = min(100, BOOTSTRAP_REPLICATES - start)
        resample = rng.multinomial(len(pages), probabilities, size=size)
        matrices = (resample @ totals).reshape(size, 2, FAIL, FAIL + 1)
        missing += int(np.any(matrices[:, 0].sum(axis=-1) == 0, axis=1).sum())
        macro = f1_of(matrices).mean(axis=-1)
        deltas.extend((macro[:, 0] - macro[:, 1]).tolist())
    q_low, lower, q_high = np.quantile(deltas, [.025, .05, .975], method="linear")
    return {"estimand": "jev-to-llm minus all-llm macro-F1",
            "delta": scores(gold, primary)["macro_f1"] - scores(gold, comparator)["macro_f1"],
            "replicates": len(deltas), "seed": BOOTSTRAP_SEED, "articles": len(pages),
            "missing_class_replicates": missing, "missing_class_fraction": missing / len(deltas),
            "one_sided_95_lower": float(lower), "two_sided_95_interval": [float(q_low), float(q_high)],
            "noninferiority_margin": -MARGIN, "noninferior": bool(lower > -MARGIN), "delta_distribution": deltas}


def risk_outputs(out, rows, gold, outputs, calibrated):
    hashes = [tie_hash(row["id"]) for row in rows]
    ranks, risk, bin_results = [], [], []
    for model in MODELS:
        pred = outputs[model]["pred"]
        for version, probs in (("raw", outputs[model]["probs"]), ("calibrated", calibrated[model])):
            mask = valid(probs)
            order = rank(probs, hashes, descending=True)
            cumulative_errors = 0
            for accepted, i in enumerate(order, start=1):
                wrong = bool(pred[i] != gold[i])
                cumulative_errors += wrong
                ranks.append({"model": model, "score_version": version, "id": rows[i]["id"], "accepted_rank": accepted,
                              "confidence": float(probs[i].max()), "tie_sha256": hashes[i], "error": wrong,
                              "coverage": accepted / len(rows), "accepted_risk": cumulative_errors / accepted})
            for i in np.flatnonzero(~mask):
                ranks.append({"model": model, "score_version": version, "id": rows[i]["id"], "accepted_rank": None,
                              "confidence": None, "tie_sha256": hashes[i], "error": bool(pred[i] != gold[i])})
            risk.append({"model": model, "score_version": version, "n": len(rows), "scored_n": len(order),
                         "unscored_n": int((~mask).sum()), "serviceable_coverage": len(order) / len(rows),
                         "accepted_risk_at_max_coverage": ratio(cumulative_errors, len(order))})
            if model == "jev":
                conf_bin = np.full(len(gold), -1)
                conf_bin[mask] = bins(probs[mask].max(axis=1))
                for b in range(-1, 10):
                    selected = conf_bin == b
                    record = decomposition(gold, pred, outputs["llm"]["pred"], selected)
                    if not np.any(selected):
                        record.update(g=None, h=None, accuracy_gain=None, oracle_gain=None)
                    bin_results.append({"score_version": version, "bin": b if b >= 0 else "unscored",
                                        "lower": b / 10 if b >= 0 else None,
                                        "upper": (b + 1) / 10 if b >= 0 else None, **record})
    write_csv(out / "risk_rankings_raw_calibrated.csv", ranks)
    write_csv(out / "risk_coverage_summary.csv", risk)
    write_csv(out / "confidence_bin_escalation.csv", bin_results)


def audit_outputs(out, rows, gold, systems, outputs, calibrated, path, mapping):
    by_id = unique(read_csv(path), "id", path)
    positions = {row["id"]: i for i, row in enumerate(rows)}
    if set(by_id) - positions.keys():
        raise ValueError(f"{path}: audit IDs outside the main test")
    if mapping is not None and by_id.keys() != mapping.keys():
        raise ValueError(f"{path}: audit IDs differ from the frozen blind review sample")
    sample_ids = sorted(by_id)
    positions = np.array([positions[identifier] for identifier in sample_ids], dtype=int)
    original = gold[positions]
    sample_counts = np.bincount(original, minlength=FAIL)
    if tuple(sample_counts) != (150, 150, 300):
        raise ValueError(f"{path}: expected S150/C150/I300 by original labels, got {sample_counts.tolist()}")
    population = np.bincount(gold, minlength=FAIL)
    weight = (population / sample_counts)[original]
    raw_adjudicated = [by_id[identifier]["adjudicated_label"] for identifier in sample_ids]
    if any(label not in (*LABELS, "", "unresolved") for label in raw_adjudicated):
        raise ValueError(f"{path}: invalid adjudicated label")
    adjudicated = np.array([LABEL_INDEX.get(label, FAIL) for label in raw_adjudicated], dtype=np.int8)
    resolved = adjudicated != FAIL
    exposure = [by_id[identifier]["exposure_status"] for identifier in sample_ids]
    clean = np.array([state.lower() in {"blind", "unexposed", "no_exposure"} for state in exposure])
    all_rows = np.ones(len(sample_ids), dtype=bool)
    weights = []
    crosstab = Counter(zip(original, adjudicated))
    for i, identifier in enumerate(sample_ids):
        weights.append({"id": identifier, "original_label": LABELS[original[i]],
                        "adjudicated_label": raw_adjudicated[i] or "unresolved", "exposure_status": exposure[i],
                        "N_h": int(population[original[i]]), "n_h": int(sample_counts[original[i]]), "weight": float(weight[i])})
    write_csv(out / "audit_weights.csv", weights)
    write_csv(out / "audit_label_crosswalk.csv", [
        {"original_label": LABELS[i], "adjudicated_label": (*LABELS, "unresolved")[j], "n": crosstab[i, j]}
        for i in range(FAIL) for j in range(FAIL + 1)
    ])
    write_json(out / "audit_coverage.json", {
        "sample_n": len(sample_ids), "resolved_n": int(resolved.sum()), "clean_resolved_n": int((clean & resolved).sum()),
        "weighted_resolved_fraction": ratio(weight[resolved].sum(), weight.sum()),
        "weighted_clean_resolved_fraction": ratio(weight[clean & resolved].sum(), weight.sum()),
        "exposure_counts": dict(Counter(exposure)),
        "by_original_label": {
            label: {"n": int(sample_counts[i]), "resolved_n": int(((original == i) & resolved).sum()),
                    "changed_n": int(((original == i) & resolved & (original != adjudicated)).sum())}
            for i, label in enumerate(LABELS)
        },
    })
    weighted, sensitivity = [], []
    scenarios = [
        ("resolved", "original", resolved, original),
        ("resolved", "adjudicated", resolved, adjudicated),
        ("clean_resolved", "original", clean & resolved, original),
        ("clean_resolved", "adjudicated", clean & resolved, adjudicated),
        ("all_600", "original", all_rows, original),
        ("all_600", "adjudicated_with_unresolved_original", all_rows, np.where(resolved, adjudicated, original)),
    ]
    for label, idx in LABEL_INDEX.items():
        scenarios.append(("all_600", f"unresolved_as_{label}", all_rows, np.where(resolved, adjudicated, idx)))
    for scope, gold_type, mask, y in scenarios:
        for name, pred in systems.items():
            result = {"scope": scope, "gold": gold_type, "system": name,
                      **scores(y[mask], pred[positions][mask], weight[mask])}
            if scope == "resolved":
                weighted.append(result)
            sensitivity.append(result)
            if name in ("all-jev", "all-nli", "all-llm"):
                model = name[4:]
                for version, p in (("raw", outputs[model]["probs"]), ("calibrated", calibrated[model])):
                    metrics, _ = probability_metrics(y[mask], pred[positions][mask], p[positions][mask], weight[mask])
                    probability_result = {"scope": scope, "gold": gold_type, "system": name,
                                          "score_version": version, **metrics}
                    if scope == "resolved":
                        weighted.append(probability_result)
                    sensitivity.append(probability_result)
    write_csv(out / "audit_metrics_weighted.csv", weighted)
    write_csv(out / "audit_sensitivity.csv", sensitivity)


def diagnostic_outputs(out, path, data_dir, pred_dir, test_ids, frozen):
    inputs = data_path(data_dir, "processed", "inputs_diagnostics.jsonl")
    if digest(inputs) != frozen["input_sha256"].get("diagnostics"):
        raise ValueError("diagnostic inputs differ from the frozen inputs")
    rows = sorted(read_jsonl(inputs), key=lambda row: row["id"])
    identifiers = set(unique(rows, "id", inputs))
    if identifiers & test_ids:
        raise ValueError("diagnostics share IDs with the main test")
    labels = unique(read_csv(path), "id", path)
    if identifiers != labels.keys():
        raise ValueError("diagnostic labels do not cover the frozen diagnostic inputs")
    groups = defaultdict(list)
    for index, row in enumerate(rows):
        record = labels[row["id"]]
        groups[record["group_id"]].append(index)
    group_rows = []
    axes = Counter()
    adjudicated = [labels[row["id"]]["adjudicated_label"] for row in rows]
    if any(label not in (*LABELS, "", "unresolved") for label in adjudicated):
        raise ValueError(f"{path}: invalid diagnostic adjudicated label")
    gold = np.array([LABEL_INDEX.get(label, FAIL) for label in adjudicated], dtype=np.int8)
    outputs = load_predictions(pred_dir, "diagnostics", rows, frozen["config_hashes"])
    systems, _ = make_systems(outputs, calibrate_all(outputs, frozen["temperatures"]), frozen["routing_policy"])
    for group, members in groups.items():
        if not group or len(members) != 2:
            raise ValueError(f"diagnostic group {group!r}: exactly two members are required")
        assessments = [labels[rows[i]["id"]] for i in members]
        metadata = {(item["axis"], item["source_type"], item.get("group_valid", "yes")) for item in assessments}
        if len(metadata) != 1:
            raise ValueError(f"diagnostic group {group}: members disagree on axis, source or group validity")
        axis, source, approval = metadata.pop()
        if source not in {"natural", "constructed"} or approval not in {"yes", "no"}:
            raise ValueError(f"diagnostic group {group}: invalid source or group-valid judgment")
        exposure = [item.get("exposure_status", "unknown") for item in assessments]
        if any(state not in {"blind", "exposed", "unknown"} for state in exposure):
            raise ValueError(f"diagnostic group {group}: invalid exposure state")
        blind = all(state == "blind" for state in exposure)
        exposed = any(state == "exposed" for state in exposure)
        axes[axis] += 1
        for name, pred in systems.items():
            a, b = members
            resolved = gold[a] != FAIL and gold[b] != FAIL
            eligible = resolved and approval == "yes"
            complete = pred[a] != FAIL and pred[b] != FAIL
            gold_changes = bool(gold[a] != gold[b]) if eligible else None
            pred_changes = bool(pred[a] != pred[b]) if complete else None
            correct = int(pred[a] == gold[a]) + int(pred[b] == gold[b]) if eligible else None
            group_rows.append({
                "group_id": group, "axis": axis, "source_type": source, "system": name,
                "group_valid": approval, "both_labels_resolved": resolved, "eligible": eligible,
                "exposure_status": "blind" if blind else ("exposed" if exposed else "unknown"),
                "id_a": rows[a]["id"], "id_b": rows[b]["id"],
                "gold_a": (*LABELS, "unresolved")[gold[a]], "gold_b": (*LABELS, "unresolved")[gold[b]],
                "pred_a": (*LABELS, "failed")[pred[a]], "pred_b": (*LABELS, "failed")[pred[b]],
                "correct_pairs": correct, "both_correct": correct == 2 if eligible else None,
                "both_predictions_valid": complete, "gold_changes": gold_changes, "pred_changes": pred_changes,
                "missed_change": bool(gold_changes and not pred_changes) if complete and eligible else None,
                "spurious_change": bool(not gold_changes and pred_changes) if complete and eligible else None,
            })
    if axes != Counter({"number": 50, "time": 50, "entity": 50, "negation": 50}):
        raise ValueError(f"diagnostic groups need 50 groups per axis, got {dict(axes)}")
    grouped = defaultdict(list)
    for row in group_rows:
        for axis, source in {(row["axis"], row["source_type"]), (row["axis"], "all"),
                             ("all", row["source_type"]), ("all", "all")}:
            grouped[axis, source, row["system"]].append(row)
    summary = []
    for (axis, source, name), group in sorted(grouped.items()):
        eligible = [row for row in group if row["eligible"]]
        for scope, scored in (("all_eligible", eligible),
                              ("blind_eligible", [row for row in eligible if row["exposure_status"] == "blind"])):
            valid_group = [row for row in scored if row["both_predictions_valid"]]
            gold_change = sum(row["gold_changes"] for row in valid_group)
            missed = sum(row["missed_change"] for row in valid_group)
            spurious = sum(row["spurious_change"] for row in valid_group)
            summary.append({"axis": axis, "source_type": source, "system": name, "scope": scope,
                            "groups": len(group), "review_eligible_groups": len(eligible), "scored_groups": len(scored),
                            "unresolved_groups": sum(not row["both_labels_resolved"] for row in group),
                            "invalid_edit_groups": sum(row["group_valid"] == "no" for row in group),
                            "exposed_groups": sum(row["exposure_status"] == "exposed" for row in group),
                            "unknown_exposure_groups": sum(row["exposure_status"] == "unknown" for row in group),
                            "pair_accuracy": ratio(sum(row["correct_pairs"] for row in scored), 2 * len(scored)),
                            "joint_accuracy": ratio(sum(row["both_correct"] for row in scored), len(scored)),
                            "valid_predictions_groups": len(valid_group), "failed_predictions_groups": len(scored) - len(valid_group),
                            "gold_change_valid_groups": gold_change, "missed_changes": missed,
                            "missed_change_rate": ratio(missed, gold_change),
                            "gold_unchanged_valid_groups": len(valid_group) - gold_change, "spurious_changes": spurious,
                            "spurious_change_rate": ratio(spurious, len(valid_group) - gold_change)})
    write_csv(out / "diagnostic_groups.csv", group_rows)
    write_csv(out / "diagnostic_summary.csv", summary)


def validate_frozen(args, manifest_path, manifest, gold_path):
    frozen = json.loads(args.freeze.read_text(encoding="utf-8"))
    canonical = json.loads(json.dumps(config_manifest()))
    if frozen["protocol"] != canonical or frozen["evaluate_py_sha256"] != digest(Path(__file__)):
        raise ValueError("evaluation code, settings or runtime differ from the frozen protocol")
    if frozen["manifest_sha256"] != digest(manifest_path):
        raise ValueError("data manifest differs from the frozen protocol")
    if frozen["prepared_manifest_sha256"] != verify_prepared(args.data):
        raise ValueError("data preparation record differs from the frozen protocol")
    if frozen["efficiency_plan_sha256"] != digest(data_path(args.data, "processed", "efficiency_plan.json")):
        raise ValueError("efficiency plan differs from the frozen protocol")
    for subset in ("calibration", "selection"):
        rows = choose_manifest(manifest, subset, COUNTS[subset])
        gold = read_gold(gold_path, rows)
        if hashlib.sha256(gold.tobytes()).hexdigest() != frozen["development_gold_sha256"][subset]:
            raise ValueError(f"{subset} gold differs from frozen labels")
        for model in MODELS:
            path = args.predictions / f"{model}_{subset}.jsonl"
            if digest(path) != frozen[f"{subset}_cache_sha256"][model]:
                raise ValueError(f"{path}: development cache differs from the frozen protocol")
    for subset, expected in frozen["input_sha256"].items():
        path = data_path(args.data, "processed", f"inputs_{subset}.jsonl")
        if digest(path) != expected:
            raise ValueError(f"{path}: inputs differ from the frozen protocol")
    return frozen


def test(args, manifest_path, manifest, gold_path):
    frozen = validate_frozen(args, manifest_path, manifest, gold_path)
    if (args.out / "run_integrity.json").exists():
        raise ValueError(f"{args.out}: completed analysis already exists; choose a fresh output directory")
    policy = frozen["routing_policy"]
    rows = choose_manifest(manifest, "test", COUNTS["test"])
    outputs = load_predictions(args.predictions, "test", rows, frozen["config_hashes"])
    calibrated = calibrate_all(outputs, frozen["temperatures"])
    systems, upgrades = make_systems(outputs, calibrated, policy)
    gold = read_gold(gold_path, rows)
    out = args.out
    base, llm = systems["all-jev"], systems["all-llm"]
    primary = systems["jev-to-llm"]
    probability_tables(out, outputs, calibrated, gold)
    risk_outputs(out, rows, gold, outputs, calibrated)
    budget_outputs(out, rows, outputs, calibrated, gold)
    metrics, decomposition_rows, routing_rows, curves = [], [], [], []
    for name, pred in systems.items():
        model = name.removesuffix("-to-llm")
        extra = {}
        if model in upgrades:
            mask = upgrades[model]
            direct = policy[model]["mode"] == "direct_all_llm"
            extra = {"mode": policy[model]["mode"], "threshold": policy[model]["threshold"],
                     "llm_calls": int(mask.sum()), "first_stage_calls": 0 if direct else len(rows)}
            decomposition_rows.append({"system": name, **extra,
                                       **decomposition(gold, outputs[model]["pred"], llm, mask)})
            conf = calibrated[model].max(axis=1)
            for i, row in enumerate(rows):
                forced = not np.isfinite(conf[i])
                routing_rows.append({"system": name, "id": row["id"], "mode": extra["mode"],
                                     "llm_called": bool(mask[i]), "forced": bool(forced and not direct),
                                     "base_confidence": float(conf[i]) if not direct and not forced else None,
                                     "pred_label": LABELS[pred[i]] if pred[i] != FAIL else None})
            for threshold in GRID:
                metrics_for_threshold = scored_route(
                    gold, outputs[model]["pred"], llm, threshold_mask(calibrated[model], threshold)
                )
                curves.append({"system": name, "threshold": threshold, **metrics_for_threshold})
        else:
            extra = {"mode": "direct_all_llm" if name == "all-llm" else "single_model",
                     "llm_calls": len(rows) if name == "all-llm" else 0,
                     "first_stage_calls": 0 if name == "all-llm" else len(rows)}
        metrics.append({"system": name, **extra, **scores(gold, pred)})
    write_csv(out / "metrics_main.csv", metrics)
    write_csv(out / "escalation_decomposition.csv", decomposition_rows)
    write_csv(out / "routing_test.csv", routing_rows)
    write_csv(out / "test_threshold_curves_descriptive.csv", curves)
    primary_calls = int(upgrades["jev"].sum())
    interval = bootstrap(rows, gold, primary, llm)
    interval.update(primary_mode=policy["jev"]["mode"], primary_llm_calls=primary_calls,
                    all_llm_calls=len(rows), fewer_llm_calls=primary_calls < len(rows),
                    noninferior_and_fewer_llm_calls=interval["noninferior"] and primary_calls < len(rows))
    write_json(out / "bootstrap_primary.json", interval)
    forced = ~valid(outputs["jev"]["probs"])
    allowed = np.flatnonzero(~forced)
    matched_metrics, matched_ids = [], []
    for seed in MATCHED_SEEDS:
        selected = random_mask(allowed, forced, primary_calls, seed)
        matched_metrics.append({"seed": seed, "forced_upgrades": int(forced.sum()),
                                **scored_route(gold, base, llm, selected)})
        matched_ids.extend({"seed": seed, "id": rows[i]["id"], "forced": bool(forced[i])}
                           for i in np.flatnonzero(selected))
    write_csv(out / "random_matched_primary.csv", matched_metrics)
    write_csv(out / "random_matched_primary_summary.csv", aggregate_seed_rows(matched_metrics, []))
    write_csv(out / "random_matched_primary_ids.csv", matched_ids, ("seed", "id", "forced"))
    if args.audit_labels is not None:
        mapping = None
        if "audit_mapping_sha256" in frozen:
            path = data_path(args.data, "restricted", "audit_mapping.csv")
            if digest(path) != frozen["audit_mapping_sha256"]:
                raise ValueError("audit mapping differs from the frozen blind review sample")
            mapping = unique(read_csv(path), "id", path)
        audit_outputs(out, rows, gold, systems, outputs, calibrated, args.audit_labels, mapping)
    if args.diagnostic_labels is not None:
        diagnostic_outputs(out, args.diagnostic_labels, args.data, args.predictions,
                           {row["id"] for row in rows}, frozen)
    write_json(out / "run_integrity.json", {
        "test_n": len(rows), "manifest_sha256": digest(manifest_path),
        "gold_sha256": hashlib.sha256(gold.tobytes()).hexdigest(),
        "protocol_freeze_sha256": digest(args.freeze),
        "config_hashes": frozen["config_hashes"],
        "test_cache_sha256": {model: outputs[model]["cache_sha256"] for model in MODELS},
        "routing_test_sha256": digest(out / "routing_test.csv"),
        "audit_labels_sha256": digest(args.audit_labels) if args.audit_labels else None,
        "diagnostic_labels_sha256": digest(args.diagnostic_labels) if args.diagnostic_labels else None,
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("freeze", "test"):
        cmd = sub.add_parser(name)
        cmd.add_argument("--data", type=Path, default=Path("data"))
        cmd.add_argument("--predictions", type=Path, default=Path("predictions"))
        cmd.add_argument("--out", type=Path, required=True)
        if name == "freeze":
            cmd.add_argument("--preflight-dir", type=Path, default=Path("results/preflight"),
                             help="Tokenizer preflight JSON files named <model>_<subset>.json.")
            cmd.add_argument("--freeze-file", action="append", default=[],
                             help="Additional model, environment, or data metadata file to fingerprint. Repeat as needed.")
        else:
            cmd.add_argument("--freeze", type=Path, required=True)
            cmd.add_argument("--audit-labels", type=Path)
            cmd.add_argument("--diagnostic-labels", type=Path)
    args = parser.parse_args()
    manifest_path = data_path(args.data, "processed", "manifest.csv")
    gold_path = data_path(args.data, "restricted", "gold_original.csv")
    try:
        manifest = list(unique(read_csv(manifest_path), "id", manifest_path).values())
        for subset, expected in COUNTS.items():
            choose_manifest(manifest, subset, expected)
        if args.command == "freeze":
            freeze(args, manifest_path, manifest, gold_path)
        else:
            test(args, manifest_path, manifest, gold_path)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(1, f"Evaluation failed: {error}\n")


if __name__ == "__main__":
    main()
