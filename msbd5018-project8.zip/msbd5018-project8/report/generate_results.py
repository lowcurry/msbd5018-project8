"""Write the ACL results section from a completed frozen test and optional live benchmark."""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import tempfile


SYSTEMS = {
    "all-jev": "Jev",
    "all-nli": "DeBERTa NLI",
    "all-llm": "All-LLM",
    "jev-to-llm": "Jev policy",
    "nli-to-llm": "NLI policy",
}
PCTS = (10, 25, 50, 75)
TEST_N = 5000
BOOTSTRAP_N = 5000


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rows(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def index(items, key):
    result = {}
    for row in items:
        value = key(row)
        if value in result:
            raise ValueError(f"duplicate result row {value!r}")
        result[value] = row
    return result


def number(value, digits=3, signed=False):
    if value in ("", None):
        return "--"
    value = float(value)
    if not math.isfinite(value):
        raise ValueError("nonfinite result")
    if value == 0:
        value = 0.
    rendered = format(value, f"{'+' if signed else ''}.{digits}f")
    return f"${rendered}$" if rendered.startswith("-") else rendered


def integer(value):
    return f"{int(value):,}"


def table(caption, label, header, records, columns):
    return "\n".join([
        r"\begin{table}[t]",
        r"\centering",
        r"\small",
        rf"\begin{{tabular}}{{{columns}}}",
        r"\toprule",
        " & ".join(header) + r" \\",
        r"\midrule",
        *(" & ".join(record) + r" \\" for record in records),
        r"\bottomrule",
        r"\end{tabular}",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\end{table}",
    ])


def verified_test(args):
    directory = args.results
    integrity = read_json(directory / "run_integrity.json")
    frozen = read_json(args.freeze)
    if integrity["test_n"] != TEST_N or integrity["protocol_freeze_sha256"] != digest(args.freeze):
        raise ValueError("expected a complete 5,000-pair test with its original protocol freeze")
    if frozen["config_hashes"] != integrity["config_hashes"]:
        raise ValueError("test and frozen model configurations differ")
    if digest(directory / "routing_test.csv") != integrity["routing_test_sha256"]:
        raise ValueError("test routing rows differ from the evaluated run")
    for model in ("jev", "nli", "llm"):
        if digest(args.predictions / f"{model}_test.jsonl") != integrity["test_cache_sha256"][model]:
            raise ValueError(f"{model} test predictions differ from the evaluated run")
    scores = index(rows(directory / "metrics_main.csv"), lambda row: row["system"])
    if set(scores) != set(SYSTEMS) or any(int(row["n"]) != TEST_N for row in scores.values()):
        raise ValueError("test metrics must include five systems scored on all 5,000 pairs")
    interval = read_json(directory / "bootstrap_primary.json")
    primary, baseline = scores["jev-to-llm"], scores["all-llm"]
    delta = float(primary["macro_f1"]) - float(baseline["macro_f1"])
    calls = int(primary["llm_calls"])
    if (
        interval["replicates"] != BOOTSTRAP_N or len(interval["delta_distribution"]) != BOOTSTRAP_N
        or not math.isclose(interval["delta"], delta, abs_tol=1e-12)
        or interval["primary_llm_calls"] != calls or interval["all_llm_calls"] != TEST_N
        or interval["primary_mode"] != frozen["routing_policy"]["jev"]["mode"]
        or interval["fewer_llm_calls"] != (calls < TEST_N)
        or interval["noninferior"] != (interval["one_sided_95_lower"] > interval["noninferiority_margin"])
    ):
        raise ValueError("primary comparison does not match the scored test and frozen policy")
    return integrity, frozen, scores, interval


def quality_table(scores):
    fields = ("macro_f1", "accuracy", "false_support_rate", "support_precision")
    return table(
        r"Test quality on 5,000 original labels. FSR is the fraction of C/I cases predicted S. S prec. is support precision.",
        "tab:main-results", ("System", "Macro-F1", "Acc.", "FSR", "S prec."),
        [[label, *(number(scores[system][field]) for field in fields)] for system, label in SYSTEMS.items()],
        "lrrrr",
    )


def class_recall(scores):
    by_system = ", ".join(
        f"{name} ({'/'.join(number(scores[key][f'recall_{label}']) for label in ('S', 'C', 'I'))})"
        for key, name in SYSTEMS.items()
    )
    failures = [f"{name} ({integer(scores[key]['failures'])})"
                for key, name in SYSTEMS.items() if int(scores[key]["failures"])]
    detail = f" Terminal failures occurred for {', '.join(failures)}." if failures else ""
    return rf"\paragraph{{Class recall.}} Recalls in S/C/I order were {by_system}." + detail


def primary_result(interval, frozen):
    lo, hi = interval["two_sided_95_interval"]
    gap = number(interval["delta"], 4, signed=True)
    lower = number(interval["one_sided_95_lower"], 4, signed=True)
    calls = interval["primary_llm_calls"]
    if interval["primary_mode"] == "cascade":
        threshold = number(frozen["routing_policy"]["jev"]["threshold"], 4)
        route = (
            f"The frozen threshold of {threshold} routed {integer(calls)} of 5,000 test pairs to the LLM. "
            "All-LLM processed all 5,000 pairs."
        )
    else:
        route = (
            "Development selection chose direct all-LLM. The frozen policy used the same 5,000 LLM "
            "predictions as the comparator."
        )
    threshold_met = (
        r"The lower bound exceeded the prespecified $-0.02$ margin."
        if interval["noninferior"]
        else r"The lower bound fell at or below the prespecified $-0.02$ margin."
    )
    return (
        r"\paragraph{Primary comparison.} " + route
        + rf" The macro-F1 difference $\Delta$ was {gap}. The one-sided 95\% lower bound was {lower} "
        + rf"and the two-sided 95\% interval was [{number(lo, 4)}, {number(hi, 4)}], "
        + f"based on {integer(interval['articles'])} test articles and 5,000 paired bootstrap replicates. "
        + threshold_met
    )


def budget_results(directory):
    metrics = index(rows(directory / "budget_ablation_metrics.csv"),
                    lambda row: (int(row["budget_pct"]), row["method"], row["seed"]))
    random = index(rows(directory / "budget_random_summary.csv"), lambda row: int(row["budget_pct"]))
    records, differences = [], []
    for pct in PCTS:
        raw = metrics[pct, "raw", ""]
        calibrated = metrics[pct, "calibrated", ""]
        budget = int(raw["target_upgrades"])
        if budget != TEST_N * pct // 100 or raw["n"] != str(TEST_N):
            raise ValueError(f"incorrect budget or test denominator for {pct}%")
        if raw["feasible"] == "False" and calibrated["feasible"] == "False":
            records.append([rf"{pct}\%", "--", "--", "--", "--"])
            continue
        summary = random[pct]
        if (
            raw["feasible"] != "True" or calibrated["feasible"] != "True"
            or int(raw["upgrades"]) != budget or int(calibrated["upgrades"]) != budget
            or int(summary["seeds"]) != 20 or float(summary["upgrades_mean"]) != budget
        ):
            raise ValueError(f"unmatched routing control at {pct}%")
        diff = float(calibrated["macro_f1"]) - float(raw["macro_f1"])
        differences.append((pct, diff))
        records.append([
            rf"{pct}\%", number(raw["macro_f1"]), number(calibrated["macro_f1"]),
            rf"{number(summary['macro_f1_mean'])} $\pm$ {number(summary['macro_f1_sd'])}",
            str(int(calibrated["g"]) - int(calibrated["h"])),
        ])
    output = table(
        r"Macro-F1 at matched escalation budgets. Random reports mean and SD across 20 seeds. "
        r"The final column is $g-h$ for calibrated routing. Dashes mark infeasible budgets.",
        "tab:budget-results", ("Budget", "Raw", "Cal.", "Random", r"$g-h$"), records, "lrrrr",
    )
    return output, differences


def escalation_result(directory, interval):
    matched = rows(directory / "random_matched_primary_summary.csv")
    if len(matched) != 1 or int(matched[0]["seeds"]) != 20:
        raise ValueError("matched random comparison needs all 20 seeds")
    if interval["primary_mode"] != "cascade":
        return ""
    escalation = index(rows(directory / "escalation_decomposition.csv"), lambda row: row["system"])
    primary = escalation["jev-to-llm"]
    if int(primary["upgrades"]) != interval["primary_llm_calls"]:
        raise ValueError("escalation counts differ from the frozen primary comparison")
    forced = sum(
        row["system"] == "jev-to-llm" and row["forced"] == "True"
        for row in rows(directory / "routing_test.csv")
    )
    return (
        r"\paragraph{Escalation outcomes.} "
        f"Invalid first-stage responses forced {integer(forced)} of the "
        f"{integer(primary['upgrades'])} escalations. "
        f"The LLM corrected {integer(primary['g'])} Jev errors and introduced {integer(primary['h'])} "
        f"errors on Jev decisions that were correct. At the same number of LLM calls, random escalation "
        f"had a mean macro-F1 of {number(matched[0]['macro_f1_mean'])} "
        rf"($\mathrm{{SD}}={number(matched[0]['macro_f1_sd'])}$ over 20 seeds)."
    )


def live_result(directory, interval):
    if directory is None:
        return r"\paragraph{Live efficiency.} Matched-load latency and throughput measurements are pending."
    context = read_json(directory / "measurement_context.json")
    if context["frozen_jev_mode"] != interval["primary_mode"] or context["concurrency"] != 1:
        raise ValueError("live benchmark differs from the frozen route or workload configuration")
    live = index(rows(directory / "real_chain_comparison.csv"), lambda row: row["method"])
    comparison = ["all-llm", "all-jev", "all-nli"]
    if interval["primary_mode"] == "cascade":
        comparison.append("jev-to-llm")
    if set(live) != set(comparison) or any(int(row["n"]) != 300 for row in live.values()):
        raise ValueError("live comparison needs complete 100-pair by 3-repeat measurements")
    parts = [
        f"{SYSTEMS[method]} measured {number(live[method]['termination_p50_ms'], 1)} ms p50 and "
        f"{number(live[method]['termination_p95_ms'], 1)} ms p95, with "
        f"{number(live[method]['successful_pairs_per_second'], 2)} successful pairs per second "
        f"and {integer(live[method]['failures'])} terminal failures"
        for method in comparison
    ]
    selected_method = "jev-to-llm" if interval["primary_mode"] == "cascade" else "all-llm"
    selected, baseline = live[selected_method], live["all-llm"]
    both_slower = all(
        float(selected[field]) > float(baseline[field])
        for field in ("termination_p50_ms", "termination_p95_ms")
    )
    timing_note = " The Jev policy was slower than local FLAN at both quantiles on this workload." if both_slower else ""
    return "\n".join([
        r"\paragraph{Live efficiency.} Each method processed the same 100 pairs in each of three "
        "repetitions at concurrency one.",
        ". ".join(parts) + "." + timing_note,
    ])


def human_status(integrity):
    audit = (
        "The independent label audit is recorded separately."
        if integrity["audit_labels_sha256"] else "The independent label audit is pending."
    )
    diagnostics = (
        "The reviewed contrastive-group analysis is recorded separately."
        if integrity["diagnostic_labels_sha256"] else "Independent diagnostic labels and edit checks are pending."
    )
    return r"\paragraph{Human evaluation.} " + audit + " " + diagnostics


def usd(value):
    return rf"US\${number(value, 4)}"


def resource_result(directory, interval):
    if directory is None:
        return ""
    accounting = read_json(directory / "accounting_inputs.json")
    if accounting["price_document"]["currency"] != "USD":
        raise ValueError("expected USD resource accounting")
    evaluated = [
        row for row in rows(directory / "resource_summary.csv")
        if row["basis"] == "actual_evaluation" and row["model"] == "jev-1.13.0"
    ]
    attempts = sum(int(row["api_attempts"]) for row in evaluated)
    unknown = sum(int(row["api_attempts_without_cost"]) for row in evaluated)
    reconciled = sum(int(row["api_attempts_billing_reconciled"]) for row in evaluated)
    amount = sum(float(row["api_priced_subtotal_usd"]) for row in evaluated)
    if attempts == 0:
        raise ValueError("resource summary has no logged Jev evaluation attempts")
    if reconciled == attempts:
        evaluation = f"The billed amount for {integer(attempts)} logged Jev evaluation attempts was {usd(amount)}."
    elif unknown:
        evaluation = (
            f"The known Jev API subtotal for {integer(attempts - unknown)} of {integer(attempts)} logged "
            f"evaluation attempts was {usd(amount)}. Missing usage or charges for "
            f"{integer(unknown)} of the attempts leave total API spend unknown."
        )
    else:
        evaluation = (
            f"The estimated API amount for {integer(attempts)} logged Jev evaluation attempts was {usd(amount)}, "
            "using logged usage and the published rate for charges without invoice reconciliation."
        )
    estimates = index(rows(directory / "deployment_estimates.csv"), lambda row: row["system"])
    selected, baseline = estimates["jev-to-llm"], estimates["all-llm"]
    if (
        selected["mode"] != interval["primary_mode"] or int(selected["llm_pairs"]) != interval["primary_llm_calls"]
        or int(baseline["llm_pairs"]) != TEST_N
        or any(row["basis"] != "offline_deployment_estimate" or int(row["test_n"]) != TEST_N
               for row in (selected, baseline))
    ):
        raise ValueError("deployment estimates do not match the frozen test and route")
    if int(selected["api_attempts_without_cost"]):
        estimate = (
            f"The selected policy's offline API subtotal is {usd(selected['api_priced_subtotal_usd'])}, "
            f"with unpriced usage on {integer(selected['api_attempts_without_cost'])} of its attempts."
        )
    else:
        estimate = f"The selected policy's offline API estimate is {usd(selected['api_total_usd'])}."
    if int(baseline["api_attempts"]) == 0:
        estimate += " The all-LLM comparator runs locally and has no API charges."
    return (
        r"\paragraph{Resource accounting.} " + evaluation + " " + estimate
        + " Local compute is unpriced in the accounting."
    )


def discussion(directory, scores, differences):
    probabilities = index(rows(directory / "calibration_metrics.csv"),
                          lambda row: (row["model"], row["score_version"]))
    raw, cal = (probabilities["jev", name] for name in ("raw", "calibrated"))
    probability = (
        f"On {integer(raw['probability_n'])} Jev examples with complete scores, NLL changed "
        f"from {number(raw['nll'])} to {number(cal['nll'])}, Brier score from {number(raw['brier'])} "
        f"to {number(cal['brier'])}, and ECE from {number(raw['ece'])} to {number(cal['ece'])} "
        "after temperature scaling."
    ) if int(raw["probability_n"]) else "The test provided no complete Jev distributions for probability scoring."
    risk_at_75 = {
        row["score_version"]: row["accepted_risk"]
        for row in rows(directory / "risk_rankings_raw_calibrated.csv")
        if row["model"] == "jev" and row["accepted_rank"] == str(TEST_N * 3 // 4)
    }
    if set(risk_at_75) == {"raw", "calibrated"}:
        probability += (
            rf" At 75\% coverage, the error rate among retained Jev decisions changed from "
            f"{number(risk_at_75['raw'])} to {number(risk_at_75['calibrated'])}."
        )
    changes = sorted(differences, key=lambda entry: entry[1])
    if changes:
        budget = (
            f"Across {len(changes)} feasible matched budgets, the change in routed macro-F1 "
            f"from raw to calibrated confidence ranged from {number(changes[0][1], 4, signed=True)} "
            f"to {number(changes[-1][1], 4, signed=True)}."
        )
    else:
        budget = "Forced escalations exceeded all four prespecified matched budgets."
    best = max(("all-jev", "all-nli", "all-llm"), key=lambda key: float(scores[key]["macro_f1"]))
    risk = (
        f"{SYSTEMS[best]} had the highest standalone macro-F1 ({number(scores[best]['macro_f1'])}) "
        f"and a false support rate of {number(scores[best]['false_support_rate'])}."
    )
    return "\n".join([
        r"\section{Discussion}",
        " ".join((risk, probability, budget)),
        "",
        "The test measures verification of a supplied passage from Wikipedia revisions. "
        "The comparison applies to the fixed prompts, models and source distribution. "
        "Article-level isolation addresses overlap across the project splits, while possible "
        "pretraining exposure and verification across multiple citations remain outside this experiment.",
        f" The local judge's support recall was {number(scores['all-llm']['recall_S'])}, "
        "which limits the quality comparison to this fallback configuration.",
    ])


def conclusion(interval, scores):
    if interval["primary_mode"] == "direct_all_llm":
        return (
            "Development selection retained direct all-LLM. The matched-budget controls quantify how Jev "
            "confidence selects fallback examples under fixed call counts."
        )
    if interval["primary_llm_calls"] == 0:
        result = (
            "met the prespecified non-inferiority criterion"
            if interval["noninferior"] else "fell short of the prespecified non-inferiority criterion"
        )
        return (
            f"With zero escalations, the frozen policy used the same predictions as standalone Jev. "
            f"It {result} against the local FLAN-T5 comparator, whose macro-F1 on this test was "
            f"{number(scores['all-llm']['macro_f1'])}. The comparison applies to this particular fallback judge. "
            "Timing and monetary costs depend on their separate measurements."
        )
    if interval["noninferior"] and interval["fewer_llm_calls"]:
        saved = TEST_N - interval["primary_llm_calls"]
        return (
            f"The frozen Jev cascade met the prespecified macro-F1 margin while saving {integer(saved)} "
            "LLM calls on the 5,000-pair test. The call difference is specific to the chosen fallback and policy."
        )
    if interval["noninferior"]:
        return (
            "The frozen Jev cascade met the macro-F1 non-inferiority margin and invoked the LLM "
            "on all 5,000 test pairs."
        )
    return (
        "The frozen Jev cascade fell short of the prespecified non-inferiority criterion. "
        "The paired interval and the correction and error counts quantify the quality of the frozen route."
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--freeze", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, default=Path("predictions"))
    parser.add_argument("--benchmark", type=Path)
    parser.add_argument("--resources", type=Path, help="Completed resources.py output for this test.")
    parser.add_argument("--out", type=Path, default=Path(__file__).with_name("results.generated.tex"))
    args = parser.parse_args()
    try:
        integrity, frozen, scores, interval = verified_test(args)
        budgets, differences = budget_results(args.results)
        parts = [
            "% Generated from frozen evaluation outputs by generate_results.py.",
            r"\section{Results}",
            quality_table(scores),
            primary_result(interval, frozen),
            class_recall(scores),
            budgets,
            escalation_result(args.results, interval),
            r"""\IfFileExists{jev_routing_evaluation.pdf}{
\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{jev_routing_evaluation.pdf}
\caption{Test risk at a given coverage among valid Jev scores (left), and macro-F1 at the four matched escalation budgets (right). Random points show means with one standard deviation over 20 seeds.}
\label{fig:routing-evaluation}
\end{figure*}
}{}""",
            r"\InputIfFileExists{case_analysis.tex}{}{}",
            human_status(integrity),
            live_result(args.benchmark, interval),
            resource_result(args.resources, interval),
            discussion(args.results, scores, differences),
            r"\section{Conclusion}",
            conclusion(interval, scores),
        ]
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=args.out.parent, prefix=".results-", delete=False,
        ) as stream:
            stream.write("\n\n".join(part for part in parts if part) + "\n")
            path = Path(stream.name)
        path.replace(args.out)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(1, f"Report generation failed: {error}\n")


if __name__ == "__main__":
    main()
