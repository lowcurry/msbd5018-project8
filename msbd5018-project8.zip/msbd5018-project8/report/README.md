# ACL manuscript

The manuscript uses the [official ACL style](https://github.com/acl-org/acl-style-files/tree/d5adc823ff0f80f98c80405ca0ab66c68e684409). The current four-page PDF includes the frozen 5,000-pair automated evaluation and matched-load measurements. Human adjudication and reviewed contrast groups are pending.

Run these commands from the project root with the frozen test caches and Python dependencies available. Matplotlib 3.11.2 was used to generate the figure.

```bash
python report/plot_results.py --results results/test --freeze results/dev/protocol_freeze.json \
  --predictions predictions --out report/jev_routing_evaluation.pdf
python report/generate_results.py --results results/test --freeze results/dev/protocol_freeze.json \
  --predictions predictions --benchmark benchmark --resources results/resources
cd report
latexmk -pdf main.tex
```

Tectonic 0.17.0 also compiled the current PDF. After independent adjudication, use the same frozen predictions to score the reviewed subsets. Interpret the audit, diagnostic and external results before updating the final manuscript. Check the final PDF, including references, against the eight-page limit.
