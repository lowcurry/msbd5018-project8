"""Plot the held-out Jev risk–coverage and matched-budget results."""
import argparse
import math
from pathlib import Path

from generate_results import PCTS, TEST_N, index, rows, verified_test


def unit(value):
    value = float(value)
    if not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError("Expected a finite value between zero and one.")
    return value


def risk_curves(directory):
    summary = index(
        (r for r in rows(directory / "risk_coverage_summary.csv") if r["model"] == "jev"),
        lambda r: r["score_version"],
    )
    ranked = rows(directory / "risk_rankings_raw_calibrated.csv")
    curves = {}
    for mode in ("raw", "calibrated"):
        ordered = sorted(
            (r for r in ranked if r["model"] == "jev" and r["score_version"] == mode and r["accepted_rank"]),
            key=lambda r: int(r["accepted_rank"]),
        )
        total = len(ordered)
        if not total or int(summary[mode]["n"]) != TEST_N or int(summary[mode]["scored_n"]) != total:
            raise ValueError(f"Missing or incomplete Jev {mode} risk coverage data.")
        curve = []
        errors = 0
        for rank, record in enumerate(ordered, 1):
            coverage = unit(record["coverage"])
            risk = unit(record["accepted_risk"])
            if record["error"] not in {"True", "False"}:
                raise ValueError("Malformed risk coverage error indicator.")
            errors += record["error"] == "True"
            if (
                int(record["accepted_rank"]) != rank
                or not math.isclose(coverage, rank / TEST_N, abs_tol=1e-12)
                or not math.isclose(risk, errors / rank, abs_tol=1e-12)
            ):
                raise ValueError(f"Jev {mode} risk coverage disagrees with its ranked errors.")
            curve.append((coverage, risk))
        if not math.isclose(curve[-1][1], unit(summary[mode]["accepted_risk_at_max_coverage"])):
            raise ValueError(f"Jev {mode} risk coverage disagrees with its summary.")
        curves[mode] = curve
    if len(curves["raw"]) != len(curves["calibrated"]):
        raise ValueError("Risk curves use different scored populations.")
    return curves


def budget_curves(directory):
    metrics = index(
        (r for r in rows(directory / "budget_ablation_metrics.csv") if r["method"] != "random"),
        lambda r: (int(r["budget_pct"]), r["method"]),
    )
    random = index(rows(directory / "budget_random_summary.csv"), lambda r: int(r["budget_pct"]))
    plot_rows = []
    infeasible = []
    for pct in PCTS:
        raw = metrics[pct, "raw"]
        cal = metrics[pct, "calibrated"]
        target = (TEST_N * pct + 99) // 100
        for row in (raw, cal):
            if int(row["n"]) != TEST_N or int(row["target_upgrades"]) != target:
                raise ValueError(f"Incorrect matched test budget at {pct}%.")
        if raw["feasible"] == cal["feasible"] == "False" and pct not in random:
            infeasible.append(pct)
            continue
        control = random[pct]
        if (
            raw["feasible"] != "True" or cal["feasible"] != "True"
            or int(raw["upgrades"]) != target or int(cal["upgrades"]) != target
            or int(control["seeds"]) != 20 or float(control["upgrades_mean"]) != target
            or float(control["n_mean"]) != TEST_N
        ):
            raise ValueError(f"Unmatched routing control at {pct}%.")
        plot_rows.append((
            pct, unit(raw["macro_f1"]), unit(cal["macro_f1"]),
            unit(control["macro_f1_mean"]), unit(control["macro_f1_sd"]),
        ))
    return plot_rows, infeasible


def draw(risks, budgets, infeasible, baseline, out):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator, PercentFormatter

    styles = {
        "raw": {"color": "#0072B2", "linestyle": "-", "label": "Raw"},
        "calibrated": {"color": "#D55E00", "linestyle": "--", "label": "Calibrated"},
    }
    with plt.rc_context({
        "font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 9,
        "axes.titleweight": "bold", "axes.labelsize": 8, "axes.spines.top": False,
        "axes.spines.right": False, "axes.linewidth": .55, "legend.fontsize": 7.4,
        "legend.frameon": False, "xtick.major.width": .55, "ytick.major.width": .55,
        "pdf.fonttype": 42, "savefig.facecolor": "white",
    }):
        figure, (risk_ax, budget_ax) = plt.subplots(1, 2, figsize=(6.55, 2.95), layout="constrained")
        for mode, points in risks.items():
            coverage, error = zip(*points)
            risk_ax.plot(coverage, error, linewidth=1.25, **styles[mode])
        risk_ax.set(
            xlabel="Accepted coverage", ylabel="Error among accepted pairs", xlim=(0, 1),
        )
        risk_ax.xaxis.set_major_formatter(PercentFormatter(1))
        risk_ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
        risk_ax.xaxis.set_major_locator(MaxNLocator(5))
        risk_ax.yaxis.set_major_locator(MaxNLocator(5))
        risk_ax.legend(loc="upper center", bbox_to_anchor=(.5, -.25), ncol=2, columnspacing=.9)

        budget_ax.axhline(baseline, color="#595959", linewidth=1.1, linestyle=":", label="Standalone Jev")
        if budgets:
            pct, raw, cal, rand, sd = zip(*budgets)
            budget_ax.plot(pct, raw, linewidth=1.2, marker="o", markersize=3.4, **styles["raw"])
            budget_ax.plot(pct, cal, linewidth=1.2, marker="s", markersize=3.4, **styles["calibrated"])
            budget_ax.errorbar(
                pct, rand, yerr=sd, color="#567457", linewidth=1.0, linestyle="-.",
                marker="D", markersize=3.0, capsize=2, label="Random mean ± SD",
            )
        if infeasible:
            note = ", ".join(f"{pct}%" for pct in infeasible)
            budget_ax.text(.98, .03, f"Infeasible: {note}", fontsize=7, ha="right", transform=budget_ax.transAxes)
        budget_ax.set(
            xlabel="Pairs escalated to the LLM", ylabel="Macro-F1", xlim=(6, 79), xticks=PCTS,
        )
        budget_ax.xaxis.set_major_formatter(PercentFormatter(100, decimals=0))
        budget_ax.yaxis.set_major_locator(MaxNLocator(5))
        budget_ax.legend(loc="upper center", bbox_to_anchor=(.5, -.25), ncol=2,
                         columnspacing=.9, handlelength=1.8)
        for axes, title in ((risk_ax, "(a) Jev risk–coverage"), (budget_ax, "(b) Matched escalation budgets")):
            axes.set_title(title, loc="left", pad=7)
            axes.set_axisbelow(True)
            axes.grid(axis="y", color="#E4E4E4", linewidth=.55)
        figure.savefig(out, format="pdf", metadata={
            "Title": "Jev risk coverage and matched escalation budgets",
            "Subject": "Frozen VitaminC-real test set of 5,000 claim and passage pairs",
        })
        plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--freeze", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.suffix.lower() != ".pdf":
        parser.error("--out must end in .pdf")
    try:
        _, _, scores, _ = verified_test(args)
        risks = risk_curves(args.results)
        budgets, infeasible = budget_curves(args.results)
        draw(risks, budgets, infeasible, unit(scores["all-jev"]["macro_f1"]), args.out)
    except (OSError, KeyError, ValueError) as error:
        parser.exit(1, f"Could not plot test results: {error}\n")


if __name__ == "__main__":
    main()
