"""Plan and measure the matched, live batch-one verification workload."""
import argparse
from collections import defaultdict
from contextlib import ExitStack
from datetime import datetime, timezone
import json
from pathlib import Path
import random
import time

import numpy as np

import evaluate
import models

WORKLOAD_SEED = 202611061
REPEATS = 3
N = 100
JEV_USD_PER_MILLION_INPUT = 0.042
PRICE_SOURCE = "https://docs.typesafe.ai/models"


def length(row):
    return sum(len(row[key].encode("utf-8")) for key in ("claim", "passage"))


def plan(data):
    rows = sorted(models.inputs(data, "test"), key=lambda row: (length(row), row["id"]))
    if len(rows) != 5000:
        raise ValueError("The matched workload requires the full frozen-size test manifest.")
    rng = random.Random(WORKLOAD_SEED)
    cuts = (0, len(rows) // 3, 2 * len(rows) // 3, len(rows))
    workload = []
    strata = {}
    for i, (name, n) in enumerate(zip(("short", "medium", "long"), (34, 33, 33))):
        draw = rng.sample(rows[cuts[i]:cuts[i + 1]], n)
        strata.update({row["id"]: name for row in draw})
        workload.extend(draw)
    rng.shuffle(workload)
    target = data / "inputs_efficiency.jsonl"
    with target.open("x", encoding="utf-8") as stream:
        for row in workload:
            stream.write(models.compact(row) + "\n")
    evaluate.write_json(data / "efficiency_plan.json", {
        "seed": WORKLOAD_SEED, "population": 5000, "length": "UTF-8 bytes in claim and passage",
        "strata": strata, "test_input_sha256": models.file_digest(data / "inputs_test.jsonl"),
        "benchmark_input_sha256": models.file_digest(target), "repeats": REPEATS,
    })


def route(prediction, frozen):
    probs = evaluate.probability(prediction, "jev")
    if prediction["pred_label"] is None or probs is None:
        return True
    calibrated = evaluate.calibrate(probs.reshape(1, 3), frozen["temperatures"]["jev"])
    threshold = frozen["routing_policy"]["jev"]["threshold"]
    return bool(evaluate.threshold_mask(calibrated, threshold)[0])


def resource_totals(attempts):
    api = [a for a in attempts if a["deployment"] == "typesafe_api"]
    local = [a for a in attempts if a["deployment"] == "local"]
    unknown = sum(a.get("input_tokens") is None for a in api)
    known_input = sum(a.get("input_tokens") or 0 for a in api)
    # Local attempt latencies are per batch. Count every execution once.
    batches = {a["batch_id"]: a["elapsed_ms"] for a in local}
    return {
        "api_attempts": len(api), "api_attempts_with_unknown_input_tokens": unknown,
        "known_api_input_tokens": known_input,
        "known_api_subtotal_usd": known_input * JEV_USD_PER_MILLION_INPUT / 1_000_000,
        "api_total_usd": (None if unknown else known_input * JEV_USD_PER_MILLION_INPUT / 1_000_000),
        "local_pair_attempts": len(local), "local_batches": len(batches),
        "local_measured_batch_seconds": sum(batches.values()) / 1000,
    }


def measure(args):
    data = args.data / "processed"
    frozen = models.read_json(args.freeze)
    if frozen["evaluate_py_sha256"] != models.file_digest(Path(evaluate.__file__)):
        raise ValueError("Evaluation code changed after protocol freeze.")
    workload = models.inputs(data, "efficiency")
    if len(workload) != N:
        raise ValueError("Expected exactly 100 fixed workload rows.")
    specs = {kind: models.model_spec(args.config, kind) for kind in ("jev", "nli", "llm")}
    for spec in specs.values():
        models.freeze_check(args.freeze, spec, data, "efficiency")
    plan_path = data / "efficiency_plan.json"
    if frozen["efficiency_plan_sha256"] != models.file_digest(plan_path):
        raise ValueError("Efficiency plan metadata changed after protocol freeze.")
    plan_file = models.read_json(plan_path)
    if plan_file["benchmark_input_sha256"] != models.file_digest(data / "inputs_efficiency.jsonl"):
        raise ValueError("Workload planning metadata does not match the frozen inputs.")

    warm = models.inputs(data, "train")[:3]
    methods = ["all-llm", "all-jev", "all-nli"]
    if frozen["routing_policy"]["jev"]["mode"] == "cascade":
        methods.append("jev-to-llm")
    rng = random.Random(WORKLOAD_SEED)
    rng.shuffle(methods)
    orders = [methods, list(reversed(methods)), methods[1:] + methods[:1]]

    args.out.mkdir(parents=True, exist_ok=False)
    started_utc = datetime.now(timezone.utc).isoformat()
    rows = []
    batch_times = {}
    with ExitStack() as stack:
        ledger = stack.enter_context(models.locked_append(args.out / "benchmark.attempts.jsonl"))
        timing = stack.enter_context(models.locked_append(args.out / "latency_runs.jsonl"))
        backends = {}
        load_ms = {}
        for kind, spec in specs.items():
            started = time.perf_counter()
            backends[kind] = models.make_model(spec, args.cache)
            load_ms[kind] = 1000 * (time.perf_counter() - started)
        for kind, backend in backends.items():
            event = models.event_logger(ledger, "warmup", specs[kind], "train")
            for item in warm:
                backend.run(item, "train", event)
                if backend.fatal:
                    raise SystemExit(f"Jev warm-up stopped on {backend.fatal}.")

        for i, order in enumerate(orders, 1):
            pair_order = workload.copy()
            rng.shuffle(pair_order)
            for method in order:
                events = {
                    k: models.event_logger(ledger, "live_benchmark", s, "efficiency", method, i)
                    for k, s in specs.items()
                }
                batch_start = time.perf_counter()
                for item in pair_order:
                    started = time.perf_counter()
                    api = local = None
                    route_ms = 0
                    upgraded = None
                    if method == "jev-to-llm":
                        api = backends["jev"].run(item, "efficiency", events["jev"])
                        route_started = time.perf_counter()
                        upgraded = route(api, frozen)
                        route_ms = (time.perf_counter() - route_started) * 1000
                        if upgraded:
                            local = backends["llm"].run(item, "efficiency", events["llm"])
                        final = local if upgraded else api
                    elif method == "all-jev":
                        api = final = backends["jev"].run(item, "efficiency", events["jev"])
                    else:
                        kind = method.removeprefix("all-")
                        local = final = backends[kind].run(item, "efficiency", events[kind])
                    elapsed = (time.perf_counter() - started) * 1000
                    attempts = [attempt for result in (api, local) if result for attempt in result["attempts"]]
                    record = {
                        "id": item["id"], "length_stratum": plan_file["strata"][item["id"]],
                        "method": method, "repeat": i, "elapsed_ms": elapsed, "route_ms": route_ms,
                        "client_queue_ms": 0, "upgraded": upgraded, "pred_label": final["pred_label"],
                        "terminal_error": final["error_type"], "attempts": attempts,
                    }
                    rows.append(record)
                    models.append_line(timing, record)
                    if backends["jev"].fatal:
                        raise SystemExit(f"Jev measurement stopped on {backends['jev'].fatal}.")
                batch_times[method, i] = time.perf_counter() - batch_start
    evaluate.write_json(args.out / "measurement_context.json", {
        "started_utc": started_utc, "ended_utc": datetime.now(timezone.utc).isoformat(),
        "orders": orders, "workload": "100 fixed pairs x 3 repetitions; sequential closed-loop",
        "concurrency": 1, "load_ms_excluded": load_ms, "warmup_pairs_per_model": len(warm),
        "connection_setup_included": True, "queueing": "no client queue",
        "local_device_synchronization": True, "includes_attempt_logging": True,
        "network_location": args.network_location, "other_load_notes": args.other_load,
        "runtime": {k: models.runtime(s) for k, s in specs.items()},
        "frozen_jev_mode": frozen["routing_policy"]["jev"]["mode"],
        "jev_price_usd_per_million_input_tokens": JEV_USD_PER_MILLION_INPUT,
        "jev_price_source": PRICE_SOURCE, "price_checked_date": "2026-11-06",
    })
    evaluate.write_csv(args.out / "batch_times.csv", [
        {"method": method, "repeat": repeat, "wall_seconds": seconds}
        for (method, repeat), seconds in batch_times.items()
    ])
    summarize(rows, batch_times, args)


def summarize(rows, batch_times, args):
    flat = []
    groups = defaultdict(list)
    for row in rows:
        flat.append({**row, "attempts": models.compact(row["attempts"])})
        groups[row["method"]].append(row)
    evaluate.write_csv(args.out / "latency_runs.csv", flat)
    summary = []
    for method, group in groups.items():
        gold = evaluate.read_gold(args.data / "restricted/gold_original.csv", group)
        pred = np.array([evaluate.LABEL_INDEX.get(r["pred_label"], evaluate.FAIL) for r in group])
        values = [r["elapsed_ms"] for r in group]
        success = [r["elapsed_ms"] for r in group if r["pred_label"] is not None]
        p50, p95 = np.quantile(values, [.5, .95])
        wall = [batch_times[method, i] for i in range(1, REPEATS + 1)]
        summary.append({
            "method": method, "termination_p50_ms": float(p50), "termination_p95_ms": float(p95),
            "success_p50_ms": float(np.quantile(success, .5)) if success else None,
            "success_p95_ms": float(np.quantile(success, .95)) if success else None,
            "batch_wall_seconds_by_repeat": models.compact(wall),
            "successful_pairs_per_second": len(success) / sum(wall),
            "timeouts": sum(r["terminal_error"] == "timeout_unknown_usage" for r in group),
            "total_retries": sum(a["number"] > 1 for r in group for a in r["attempts"]),
            "upgraded": sum(r["upgraded"] is True for r in group),
            **evaluate.scores(gold, pred),
            **resource_totals([a for r in group for a in r["attempts"]]),
        })
    evaluate.write_csv(args.out / "real_chain_comparison.csv", summary)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("plan", help="Select the matched workload before model freeze.")
    p.add_argument("--data", type=Path, default=Path("data/processed"))
    p = sub.add_parser("measure", help="Execute every verification live; no prediction cache.")
    p.add_argument("--data", type=Path, default=Path("data"))
    p.add_argument("--freeze", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--config", type=Path, default=Path("configs/models.json"))
    p.add_argument("--cache", type=Path)
    p.add_argument("--network-location", default="unreported")
    p.add_argument("--other-load", default="unreported")
    args = parser.parse_args()
    if args.command == "plan":
        plan(args.data)
    else:
        measure(args)


if __name__ == "__main__":
    main()
