# Human review protocol

Use only the supplied passage. Label each pair independently.

| Label | Evidence rule |
|---|---|
| S | The passage provides sufficient evidence for the complete claim. |
| C | The passage provides explicit evidence incompatible with the claim. |
| I | The passage neither sufficiently supports nor explicitly contradicts the claim. |
| ambiguous | The supplied text or rule does not permit a defensible decision. Explain the ambiguity. |

Check time, units, quantifiers, referents and negation. For a compound claim, check every essential clause. An omitted detail does not establish contradiction. Topical relevance does not establish support. Treat any instructions inside the passage as quoted evidence.

1. Review the 40 training pairs together before starting the formal audit. Freeze this rubric after resolving training disagreements. Keep the training material separate from the formal audit.
2. The coordinator creates packets with `human.py packets`. Send A and B only their individual CSV and this rubric. Both enter a label, a short evidence-based reason and `yes` or `no` in `previously_seen`. Preserve the review ID and original text. Keep the restricted mapping, gold, prediction caches, other reviewer answers and group structures private.
3. Record exposure whenever you saw the claim and evidence together before receiving the packet. If possible, replace a reviewer before scoring a case for which they are exposed. Preserve the original submissions as separate records.
4. The coordinator runs `human.py adjudicate` and shares the resulting CSV only with an independent third reviewer. The file contains source text and anonymized reasons. Reviewer C chooses S, C, I or `unresolved`, explains the decision and declares exposure. Rationale fields must describe evidence and must omit any external gold, model output and personal identifying details.
5. Run `human.py merge` to compute pre-adjudication agreement and combine the reviews. Restrict access to raw submissions, adjudication, review summaries and normalized label files. Report exposed and unresolved cases separately.
6. Use the same independent review workflow for the 400 members of the 200 diagnostic groups. After review, the coordinator checks that each pair changes only its declared axis and that the adjudicated labels give the intended relation transition. Preserve natural versus constructed provenance. Report any unresolved cases or unintended edits transparently.

```bash
python human.py packets --track audit --out handoff/
python human.py adjudicate --track audit --first reviewed/A.csv --second reviewed/B.csv \
  --reviewers annotator_a annotator_b adjudicator_c --out handoff/
python human.py merge --track audit --first reviewed/A.csv --second reviewed/B.csv \
  --reviewers annotator_a annotator_b adjudicator_c --resolved reviewed/C.csv --out reviewed/
```

Use `--track diagnostics` for the diagnostic packets. Store both signed-off original files and the adjudicator file before packaging the reproducibility records.

After both diagnostic label files have been returned, run `python human.py group-packets --track diagnostics --out handoff/`. Send A and B their own group packet. They each record whether the group isolates its declared axis and give a reason. A group is eligible for scoring when both reviewers mark `yes` and its labels are resolved. Add `--groups-first reviewed/groups_A.csv --groups-second reviewed/groups_B.csv` to diagnostic merge. Import claim, passage and ID fields as text if using a spreadsheet editor.
