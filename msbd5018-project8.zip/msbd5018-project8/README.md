# MSBD 5018 Project 8 Group 16

本目录实现 **Evaluating Jev for RAG Citation Verification**。课程说明确定提交物和格式，原有一页英文 proposal 确定实验设计，两份 Markdown 用于细化实现。从 [组员交接文档](GROUP_PROJECT_HANDOFF.md) 开始，查看已完成结果、四模型扩展、盲审分工和提交节点。[原冻结实验状态](STATUS.md) 记录了主实验的详细背景。

本仓库是组员协作快照，包含代码、配置、汇总结果和报告材料。逐条标签、预测缓存和审核表由协调者单独保管。下文涉及这些材料的命令由协调者在完整工作目录中运行。

## 课程提交

| 交付 | 要求 | 本目录入口 |
|---|---|---|
| Proposal | 10 月 17 日 23:59，一页 PDF，任务、重要性和拟采用方法 | 协调者持有原 `Project8_Proposal.pdf` |
| Results | 11 月 17 日 23:59，在 Canvas 提交主要评价分数 | `results/MAIN_RESULTS.md`、`results/test/metrics_main.csv` 与 `results/test/bootstrap_primary.json` |
| Final report | 12 月 9 日 23:59，官方 ACL 模板，最多 8 页 | `report/Project8_ACL_Automated_Results.pdf` 与可编辑 ACL 源码，人工结果待补 |
| Code and data | 12 月 9 日 23:59，复现代码和数据或可访问链接 | 本目录、作者下载链接，另由协调者提供冻结清单和预测缓存 |
| Presentation | 时间以课程公告为准，指南预估 5 分钟 | `presentation/Project8_Automated_Results.pptx`，含逐页讲者备注 |

## 复现步骤

命令从本目录运行。冻结结果使用 Python 3.12.13 和 NumPy 2.5.4。请使用该 Python 版本创建独立虚拟环境。本机开发运行的完整版本见 `requirements-lock-macos-arm64-py312.txt`。

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-inference.txt numpy==2.5.4
```

### 1. 确定数据与先前查看记录

作者发布 [VitaminC fact verification ZIP](https://github.com/TalSchuster/talschuster.github.io/raw/master/static/vitaminc.zip)。原始数据、license 与引用见 [作者仓库](https://github.com/TalSchuster/VitaminC)。原始下载和输入在统计上应使用同一固定快照，具体 SHA-256 见 `data/processed/freeze_manifest.json`。如果目录里有本次准备的数据，先查验其中的先前查看状态，保留该版本和生成日志。

```bash
python prepare.py --source data_source/vitaminc.zip \
  --source-url https://github.com/TalSchuster/talschuster.github.io/raw/master/static/vitaminc.zip \
  --output data_v2 --max-bytes 900 --pilot /path/to/pilot.csv
```

`pilot.csv` 包含 `id,page` 表头，填写全组先前看过的官方 test ID 或文章名。全组确认没有查看过官方 test 后，可用 `--no-prior-test-exposure` 替代 `--pilot`，并保存确认依据。将新清单作为下文的 `data` 目录，归档旧清单、盲审包、预测缓存和预检记录。只有 ID、输入哈希和模型配置完全一致的开发缓存可复用。原始 VitaminC-real 正文保持完整。首次长度检查发现一条选择样本达到 521 个 FLAN token，超过 512 限制，所以在读取选择集成绩前统一收紧字节筛选并重建清单。当前规则以 900 个 UTF-8 字节筛查 claim 与 passage 总长度，并对实际本地 tokenizer 再检查。超限应在正式冻结前重建共同候选池。

```bash
python benchmark.py plan --data data/processed
for subset in train calibration selection test diagnostics; do
  python models.py preflight --model nli --subset "$subset"
  python models.py preflight --model llm --subset "$subset"
  python models.py preflight --model llm --subset "$subset" --config configs/models_flan_small.json
done
```

`models.py` 可用 `--cache /path/to/huggingface/hub` 指定标准 Hugging Face 模型缓存。Jev 通过环境变量 `JEV_KEY` 认证。运行前在本机环境中安全配置该变量。确认提供方模型可用后，在 train 上验收 rubric、标签映射、完整概率、同一正文和失败行为。数据集推理可使用 `run_jev.py --config configs/models_selected.json --subset calibration --workers 16`，其缓存与原入口兼容。真实链路基准仍由 `benchmark.py` 串行执行。

### 2. 开发集选择

开发阶段登记两个本地 LLM 候选 FLAN-T5-base 与 FLAN-T5-small。二者使用固定版本、相同 rubric 和完整 S/C/I 序列评分，按 selection macro-F1、相同负载下的中位耗时、base 优先的顺序选择。仅对最终选定模型在 calibration 上拟合温度。较大运行可增加批量，但两个候选的批量和设备必须一致。

```bash
python models.py run --model llm --subset selection --predictions predictions --batch-size 16
python models.py run --model llm --subset selection --config configs/models_flan_small.json \
  --predictions predictions_flan_small --batch-size 16
python select_llm.py --base predictions --small predictions_flan_small
```

若 small 胜出，归档主预测目录所有 base 候选的 `llm_*` 缓存和账本，再把 small 的 train 和 selection 缓存、运行元数据和账本复制到主预测目录。实际开销汇总需同时包含未入选候选的原始账本。模型配置使用生成的 `configs/models_selected.json`。完成候选选择且缓存完整时可以直接进入下一步。

```bash
for model in jev nli llm; do
  python models.py run --config configs/models_selected.json --model "$model" --subset train --batch-size 16
  for subset in calibration selection; do
    python models.py run --config configs/models_selected.json --model "$model" --subset "$subset" --batch-size 16
  done
done
```

正式冻结需要最终选中模型与 NLI 的逐子集 tokenizer 检查记录。

```bash
mkdir -p results/preflight
for model in nli llm; do
  for subset in train calibration selection test diagnostics efficiency; do
    python models.py preflight --config configs/models_selected.json --model "$model" \
      --subset "$subset" > "results/preflight/${model}_${subset}.json" || exit 1
  done
done
python evaluate.py freeze --data data --predictions predictions --out results/dev \
  --freeze-file configs/models_selected.json --freeze-file results/dev/llm_selection.json \
  --freeze-file configs/checkpoint_manifest.json --freeze-file models.py --freeze-file run_jev.py --freeze-file benchmark.py
```

确认冻结文件记录的清单、模型、运行环境、温度、阈值、诊断集与计时负载。模型、阈值、评分规则和工作负载固定之后执行正式测试。

### 3. 双人盲审与诊断核验

按 [标注协议](ANNOTATION.md) 生成和分发 CSV。安排两人分别盲标 600 条主测试样本，并由独立第三人盲裁决。对 200 组诊断分别做标签审核和对照编辑检查。记录接触过的样本和未决项。只把个人盲标文件及 rubric 发给相应标注者。数据管理者保管原标签、测试映射、诊断预期、两份原始回答和裁决记录。

### 4. 主测试和真实链路

```bash
for subset in test diagnostics; do
  for model in jev nli llm; do
    python models.py run --config configs/models_selected.json --model "$model" \
      --subset "$subset" --freeze results/dev/protocol_freeze.json --batch-size 16
  done
done
python evaluate.py test --data data --predictions predictions --out results/test \
  --freeze results/dev/protocol_freeze.json
python benchmark.py measure --freeze results/dev/protocol_freeze.json \
  --config configs/models_selected.json --out benchmark \
  --network-location 'record actual site' --other-load 'record actual background load'
python resources.py --predictions predictions --ledger-dir predictions_flan_small \
  --ledger-dir results/dev/reworked_attempts --results results/test \
  --benchmark benchmark --prices configs/prices.json \
  --out results/resources
```

保留所有缓存、错误、尝试账本和版本。评估、部署估计和实测链路分开陈列。盲审和诊断核验完成后，用同一份冻结清单和预测缓存补算人工结果。

```bash
python evaluate.py test --data data --predictions predictions --out results/test_with_review \
  --freeze results/dev/protocol_freeze.json \
  --audit-labels reviewed/audit_labels.csv --diagnostic-labels reviewed/diagnostics_labels.csv
```

正式报告同时呈现测试总体、区间、失败、错误升级修复与破坏、预算消融、审计与诊断覆盖。根据真实数据写结果与误差分析，编译 ACL PDF 和更新演示稿。提交前核对 Canvas 的 results 样例和最新演示规则。

## 数据来源与复用

- VitaminC 源文本适用各 Wikipedia 页面所列许可，页面许可不可得时作者发布文件使用 CC BY-SA 3.0。共享派生的 evidence 样本时保留原作者、来源和适用许可。见 [VitaminC DATA_LICENSE](https://github.com/TalSchuster/VitaminC/blob/main/DATA_LICENSE) 和 [原论文](https://aclanthology.org/2021.naacl-main.52/)。
- Jev 请求按 [TypeSafe System One](https://docs.typesafe.ai/api/system-one) 实现。参考方案中的 [Paper Trellis 接口实现](https://github.com/MarissaFamularo/citation-verifier/blob/fad6eb6ad1c8e0f235c3afbfab3efd6153ce915f/src/lib/typesafe.js) 用于核对接口设计。
- ALCE 是优先外部验证。已有的 0/1/2 citation precision 衡量支持程度。外部验证需要恢复真实引用并独立标注 S/C/I。见 [ALCE 作者的人工评估说明](https://github.com/princeton-nlp/ALCE/blob/main/human_eval/README.md)。
