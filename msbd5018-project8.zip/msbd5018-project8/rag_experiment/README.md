# 四模型 RAG 与 Jev 前置重排实验

每个模型在同一批问题上配对运行两组。Baseline 直接取固定检索排序的前 5 段。Jev 组用 Jev Choice 为同一问题的 10 段候选分别打相关性分，再取前 5 段交给同一个回答模型。相关性包括直接回答问题的证据和能连接其中一步的线索。同分保留原检索次序。

两组使用相同的问题、候选池、上下文段数、回答提示和模型请求参数。区别是提供给回答模型的段落及其排序。模型使用供应商默认解码参数，除非事先在对应 `request_options` 中配置。正式批次固定配置后再跑两组。每题的 Jev 评分只计算一次，由四个模型共享。程序记录各阶段耗时和返回的用量字段，生成请求耗时与 Jev 评分耗时各自保存。

| 模型 | API 模型 ID | 官方来源 |
|---|---|---|
| GLM-5.3 | `glm-5.3` | [智谱](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.3) |
| Kimi K3.1 Pro | `kimi-k3.1-pro` | [月之暗面](https://www.kimi.com/en/blog/kimi-k3-1-pro) |
| DeepSeek-V4.1-Flash-1017 | `deepseek-flash` | [DeepSeek](https://api-docs.deepseek.com/updates/) |
| Qwen3.8-Max | `qwen3.8-max` | [阿里云百炼](https://help.aliyun.com/zh/model-studio/qwen3-8-max) |

Kimi 默认使用普通 Pro。DeepSeek 原厂 ID 是滚动别名，官方文档当前将它映射到 Flash-1017。正式运行前按所选接入平台核对映射及版本。若供应商返回不同的模型 ID，先核对该名称再将它明确列入对应模型的 `allowed_served_models`。日志记录请求的模型 ID 和服务端返回的模型名。四家 `base_url` 和 `api_key_env` 均留空。配置时填入 API 基址和环境变量名，将密钥本身保存在环境变量里。Jev 使用已有的 `JEV_KEY`。

## 评测样本

默认评测使用 HotpotQA 的公开 distractor 开发集。脚本固定抽取 200 题，在作者给定的每题 10 个段落内按 BM25 排序。候选池包含标注证据，段落召回率衡量重排后的证据保留情况。另可提供你们自己的已排序候选池。 [HotpotQA 作者主页与数据下载](https://hotpotqa.github.io/)

输入是一题一行的 JSONL。每行含唯一的 `example_id`、`question`、可接受的参考短答案列表 `answers` 和已按 baseline 检索顺序排列的 `candidates`。候选项含 `id` 和 `text`。可另给 `gold_evidence_ids` 指明人工标注的证据段落。推理程序只向 API 发送问题和候选段落文本。参考答案和标注证据用于本地评分。

从 `Project8` 根目录执行以下命令。数据入口也接受团队自己准备的同格式清单。

```bash
python3 rag_experiment/prepare_hotpotqa.py \
  --source /path/to/hotpot_dev_distractor_v1.json \
  --out rag_experiment/data/hotpot_dev_200.jsonl

python3 rag_experiment/run.py plan \
  --manifest rag_experiment/data/hotpot_dev_200.jsonl
```

`plan` 在本地检查问题、候选段落、模型配置和预定请求量。200 题对应 1,600 个回答试验和 2,000 个共享的 Jev 评分请求。填好四家连接配置与环境变量后，可以运行以下命令。

```bash
python3 rag_experiment/run.py run \
  --manifest rag_experiment/data/hotpot_dev_200.jsonl \
  --output rag_experiment/results/first_run

python3 rag_experiment/score.py \
  --manifest rag_experiment/data/hotpot_dev_200.jsonl \
  --runs rag_experiment/results/first_run/runs.jsonl \
  --model glm53 --model kimi_k31 --model deepseek_flash1017 --model qwen38_max \
  --output rag_experiment/results/first_run/scores.json
```

## 两个主分数

**Baseline 分数**为四个模型各自答案 Exact Match 的等权平均。**Jev 前置分数**按同样方法计算。每题的预测与任一参考答案规范化后一致即计 1。另报告各模型两组的分数、配对变化与 95% 置信区间，以及 token F1 和有证据标签时的段落召回率。区间按题目配对重采样。

回答失败计 0。若一题的 Jev 重排评分失败，该题四个 Jev 组试验均记为失败。认证、端点或模型身份错误会中止批次，便于修正连接。运行目录记录配置、样本和代码哈希，固定版本下可续跑尚未写入的记录。评分要求两组和四模型覆盖完全相同的问题。跨实验比较时保留这批问题和配置快照。
