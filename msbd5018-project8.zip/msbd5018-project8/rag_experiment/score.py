"""Score paired RAG answer predictions against a held-out alias manifest."""

import argparse
from collections import Counter
import json
import math
import os
from pathlib import Path
import random
import re
import statistics
import string
import tempfile
import unicodedata


ARMS = ("baseline", "jev_before")
METRICS = ("exact_match", "token_f1")
ARTICLES = re.compile(r"\b(a|an|the)\b")
ASCII_PUNCTUATION = frozenset(string.punctuation)
CATEGORICAL_ANSWERS = {"yes", "no", "noanswer"}


def normalize_answer(answer):
    """Normalize case, Unicode, punctuation, English articles and whitespace."""
    normalized = unicodedata.normalize("NFKC", answer).casefold()
    normalized = "".join(
        char for char in normalized
        if char not in ASCII_PUNCTUATION and not unicodedata.category(char).startswith("P")
    )
    return " ".join(ARTICLES.sub(" ", normalized).split())


def token_f1(prediction, reference):
    """Compute token overlap with repeated tokens counted."""
    if prediction != reference and (
        prediction in CATEGORICAL_ANSWERS or reference in CATEGORICAL_ANSWERS
    ):
        return 0.0
    pred_tokens = prediction.split()
    ref_tokens = reference.split()
    if not pred_tokens or not ref_tokens:
        return float(pred_tokens == ref_tokens)
    common = sum((Counter(pred_tokens) & Counter(ref_tokens)).values())
    return 2 * common / (len(pred_tokens) + len(ref_tokens))


def score_prediction(row, references, gold_evidence):
    prediction = row["prediction"]
    context = row["context_ids"]
    recall = len(context & gold_evidence) / len(gold_evidence) if gold_evidence and context is not None else None
    failed = row["error"] is not None or prediction is None or not prediction.strip()
    if failed:
        return {"exact_match": 0.0, "token_f1": 0.0, "evidence_recall": recall, "failed": True}
    answer = normalize_answer(prediction)
    return {
        "exact_match": float(answer in references),
        "token_f1": max(token_f1(answer, ref) for ref in references),
        "evidence_recall": recall,
        "failed": False,
    }


def read_jsonl(path):
    with path.open(encoding="utf-8") as file:
        for line_num, line in enumerate(file, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_num}: {exc.msg}") from exc
            if not isinstance(row, dict):
                raise ValueError(f"{path}:{line_num}: expected a JSON object")
            yield row


def require_text(row, field, context):
    value = row.get(field)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{context}: {field} must be a nonempty string")
    return value


def optional_ids(row, field, context):
    value = row.get(field)
    if value is None:
        return None
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError(f"{context}: {field} must be a list of nonempty strings or null")
    return set(value)


def manifest_index(manifest):
    indexed = {}
    for row in manifest:
        identifier = require_text(row, "example_id", "manifest")
        context = f"manifest example {identifier!r}"
        if identifier in indexed:
            raise ValueError(f"{context}: duplicate example ID")
        require_text(row, "question", context)
        aliases = row.get("answers")
        if not isinstance(aliases, list) or not aliases or any(
            not isinstance(alias, str) or not alias.strip() for alias in aliases
        ):
            raise ValueError(f"{context}: answers must be a nonempty list of nonempty strings")
        indexed[identifier] = (
            {normalize_answer(alias) for alias in aliases},
            optional_ids(row, "gold_evidence_ids", context),
        )
    if not indexed:
        raise ValueError("manifest contains no questions")
    return indexed


def run_index(runs, examples, models):
    indexed = {}
    for row in runs:
        identifier = require_text(row, "example_id", "run")
        model = require_text(row, "model", f"run {identifier!r}")
        arm = require_text(row, "arm", f"run {identifier!r}")
        key = (identifier, model, arm)
        if identifier not in examples:
            raise ValueError(f"unknown run example ID: {identifier!r}")
        if model not in models or arm not in ARMS:
            raise ValueError(f"unexpected run model or arm: {key!r}")
        if key in indexed:
            raise ValueError(f"duplicate run slot: {key!r}")
        for field in ("prediction", "error"):
            if field not in row or (row[field] is not None and not isinstance(row[field], str)):
                raise ValueError(f"run {key!r}: {field} must be a string or null")
        indexed[key] = {**row, "context_ids": optional_ids(row, "context_ids", f"run {key!r}")}

    missing = [
        (identifier, model, arm)
        for identifier in sorted(examples)
        for model in models
        for arm in ARMS
        if (identifier, model, arm) not in indexed
    ]
    if missing:
        raise ValueError(f"missing {len(missing)} expected run slots, first five: {missing[:5]!r}")
    return indexed


def quantile(sorted_values, percentile):
    index = (len(sorted_values) - 1) * percentile
    lower = math.floor(index)
    upper = math.ceil(index)
    return sorted_values[lower] + (index - lower) * (sorted_values[upper] - sorted_values[lower])


def bootstrap_interval(deltas, replicates, seed):
    """Percentile intervals from resampling the same questions in both arms."""
    n = len(deltas)
    rng = random.Random(seed)
    em_values, f1_values = zip(*deltas)
    em_bootstrap, f1_bootstrap = [], []
    for _ in range(replicates):
        sample = rng.choices(range(n), k=n)
        em_bootstrap.append(math.fsum(em_values[index] for index in sample) / n)
        f1_bootstrap.append(math.fsum(f1_values[index] for index in sample) / n)
    for values in (em_bootstrap, f1_bootstrap):
        values.sort()
    return {
        "exact_match": [quantile(em_bootstrap, 0.025), quantile(em_bootstrap, 0.975)],
        "token_f1": [quantile(f1_bootstrap, 0.025), quantile(f1_bootstrap, 0.975)],
    }


def paired_summary(deltas, replicates, seed):
    intervals = bootstrap_interval(deltas, replicates, seed)
    return {
        metric: {"mean": statistics.fmean(values), "ci_95": intervals[metric]}
        for metric, values in zip(METRICS, zip(*deltas))
    }


def summarize_model(model, indexed, examples, replicates, seed):
    questions = []
    for identifier in sorted(examples):
        references, gold_evidence = examples[identifier]
        arms = {
            arm: score_prediction(indexed[(identifier, model, arm)], references, gold_evidence)
            for arm in ARMS
        }
        delta = {
            metric: arms["jev_before"][metric] - arms["baseline"][metric]
            for metric in METRICS
        }
        before_recall = arms["baseline"]["evidence_recall"]
        after_recall = arms["jev_before"]["evidence_recall"]
        delta["evidence_recall"] = (
            after_recall - before_recall if before_recall is not None and after_recall is not None else None
        )
        questions.append({"example_id": identifier, **arms, "paired_delta": delta})

    totals = {}
    annotated_count = sum(bool(gold_evidence) for _, gold_evidence in examples.values())
    for arm in ARMS:
        total_failed = sum(question[arm]["failed"] for question in questions)
        recall = [question[arm]["evidence_recall"] for question in questions
                  if question[arm]["evidence_recall"] is not None]
        totals[arm] = {
            "n": len(questions),
            "failures": total_failed,
            "failure_rate": total_failed / len(questions),
            "evidence_annotated_n": annotated_count,
            "evidence_scored_n": len(recall),
            "evidence_recall": statistics.fmean(recall) if recall else None,
            **{
                metric: statistics.fmean(question[arm][metric] for question in questions)
                for metric in METRICS
            },
        }

    paired = [(q["paired_delta"]["exact_match"], q["paired_delta"]["token_f1"]) for q in questions]
    paired_recall = [q["paired_delta"]["evidence_recall"] for q in questions
                     if q["paired_delta"]["evidence_recall"] is not None]
    return {
        **totals,
        "paired_delta": {
            **paired_summary(paired, replicates, seed),
            "evidence_recall": {
                "n": len(paired_recall),
                "mean": statistics.fmean(paired_recall) if paired_recall else None,
            },
        },
        "paired_exact_match_counts": {
            "improved": sum(exact > 0 for exact, _ in paired),
            "worsened": sum(exact < 0 for exact, _ in paired),
            "unchanged": sum(exact == 0 for exact, _ in paired),
        },
        "questions": questions,
    }


def summarize_overall(models, replicates, seed):
    model_summaries = list(models.values())
    question_rows = [summary["questions"] for summary in model_summaries]
    n_questions = len(question_rows[0])
    slots = n_questions * len(model_summaries)
    per_arm = {}
    for arm in ARMS:
        failures = sum(summary[arm]["failures"] for summary in model_summaries)
        per_arm[arm] = {
            "model_question_slots": slots,
            "failures": failures,
            "failure_rate": failures / slots,
            **{
                metric: statistics.fmean(summary[arm][metric] for summary in model_summaries)
                for metric in METRICS
            },
        }
    # Keep every model's pair together for each resampled question.
    paired = [
        tuple(statistics.fmean(row["paired_delta"][metric] for row in aligned_rows) for metric in METRICS)
        for aligned_rows in zip(*question_rows)
    ]
    return {
        "n_questions": n_questions,
        "n_models": len(model_summaries),
        **per_arm,
        "paired_delta": paired_summary(paired, replicates, seed),
    }


def score_runs(manifest, runs, models, bootstrap_replicates=5000, seed=42):
    """Return per-model macro metrics and paired comparisons for complete runs."""
    models = tuple(models)
    if not models or any(
        not isinstance(model, str) or not model.strip() for model in models
    ) or len(set(models)) != len(models):
        raise ValueError("expected models must be distinct nonempty strings")
    if bootstrap_replicates < 1:
        raise ValueError("bootstrap replicates must be positive")
    examples = manifest_index(manifest)
    indexed = run_index(runs, examples, models)
    model_results = {
        model: summarize_model(model, indexed, examples, bootstrap_replicates, seed)
        for model in models
    }
    return {
        "n_questions": len(examples),
        "primary_metric": "normalized_exact_match",
        "secondary_metric": "token_f1",
        "metric_scale": "fraction",
        "aggregation": "equal weight per question and model; best matching answer alias per metric",
        "comparison": "jev_before minus baseline",
        "normalization": "NFKC, case folding, ASCII and Unicode punctuation removal, English article removal, whitespace collapse",
        "failure_rule": "non-null error, null prediction, or blank prediction scores zero on both metrics",
        "evidence_metric": "distinct context IDs found among gold evidence IDs, divided by distinct gold IDs; only scored when both are available",
        "bootstrap": {
            "unit": "paired question, with all model pairs kept together for the overall comparison",
            "interval": "two-sided 95% percentile",
            "replicates": bootstrap_replicates,
            "seed": seed,
        },
        "overall": summarize_overall(model_results, bootstrap_replicates, seed),
        "models": model_results,
    }


def write_report(path, report):
    """Publish a complete report so interrupted writes leave the previous report intact."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", delete=False
    )
    temp_path = Path(temporary.name)
    try:
        with temporary:
            json.dump(report, temporary, ensure_ascii=False, indent=2, allow_nan=False)
            temporary.write("\n")
        os.replace(temp_path, path)
    finally:
        temp_path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--model", action="append", required=True, help="Expected model slot, repeat per model")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.output.resolve() in {args.manifest.resolve(), args.runs.resolve()}:
        parser.error("output must differ from the manifest and run files")
    try:
        report = score_runs(read_jsonl(args.manifest), read_jsonl(args.runs), args.model,
                            args.bootstrap_replicates, args.seed)
        write_report(args.output, report)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"{parser.prog}: {exc}\n")


if __name__ == "__main__":
    main()
