"""Adapt the official HotpotQA distractor dev release to a fixed-pool RAG benchmark."""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re


SOURCE = "https://curtis.ml.cmu.edu/datasets/hotpot/hotpot_dev_distractor_v1.json"
MIRROR = ("https://huggingface.co/datasets/RAGLAB/data/resolve/c33b09b/"
          "eval_datasets/HotPotQA/hotpot_dev_distractor_v1.json")
RELEASE_SHA256 = "4e9ecb5c8d3b719f624d66b60f8d56bf227f03914f5f0753d6fa1b359d7104ea"
PAPER = "https://aclanthology.org/D18-1259/"
LICENSE = "https://creativecommons.org/licenses/by-sa/4.0/"
TOKEN = re.compile(r"[^\W_]+")
POOL_SIZE = 10
BM25_K1 = 1.2
BM25_B = 0.75
SAMPLE_PREFIX = "hotpotqa-distractor-dev-v1"


def tokens(text):
    return TOKEN.findall(text.casefold())


def bm25_order(question, passages):
    """Rank the fixed candidate pool using title and passage text, with source-order ties."""
    terms = set(tokens(question))
    documents = [Counter(tokens(passage["text"])) for passage in passages]
    lengths = [sum(document.values()) for document in documents]
    average = sum(lengths) / len(documents)
    if not average:
        raise ValueError("candidate pool has no lexical tokens")
    idf = {}
    for term in sorted(terms):
        frequency = sum(term in document for document in documents)
        idf[term] = math.log1p((len(documents) - frequency + .5) / (frequency + .5))

    scores = []
    for document, length in zip(documents, lengths):
        length_norm = BM25_K1 * (1 - BM25_B + BM25_B * length / average)
        scores.append(sum(
            weight * document[term] * (BM25_K1 + 1) / (document[term] + length_norm)
            for term, weight in idf.items()
        ))
    return [passages[i] for i in sorted(range(len(passages)), key=lambda i: (-scores[i], i))]


def adapt(row):
    identifier = row["_id"]
    question, answer = row["question"].strip(), row["answer"].strip()
    if not question or not answer:
        raise ValueError(f"{identifier}: missing question or answer")
    passages = []
    titles = {}
    for i, (title, sentences) in enumerate(row["context"], 1):
        if not title.strip() or title in titles or not sentences:
            raise ValueError(f"{identifier}: missing passage or ambiguous document title")
        passage = " ".join(sentence.strip() for sentence in sentences if sentence.strip())
        if not passage:
            raise ValueError(f"{identifier}: empty passage")
        passage_id = f"p{i:02d}"
        passages.append({"id": passage_id, "text": f"{title}\n{passage}"})
        titles[title] = (passage_id, len(sentences))
    if len(passages) != POOL_SIZE:
        raise ValueError(f"{identifier}: expected {POOL_SIZE} distractor candidates")
    evidence = set()
    for title, sentence_index in row["supporting_facts"]:
        if title not in titles or type(sentence_index) is not int or not 0 <= sentence_index < titles[title][1]:
            raise ValueError(f"{identifier}: supporting fact outside the candidate pool")
        evidence.add(titles[title][0])
    if not evidence:
        raise ValueError(f"{identifier}: missing supporting documents")
    return {
        "example_id": identifier,
        "question": question,
        "answers": [answer],
        "candidates": bm25_order(question, passages),
        "gold_evidence_ids": sorted(evidence),
    }


def selection_key(identifier, seed):
    key = f"{SAMPLE_PREFIX}|{seed}|{identifier}".encode("utf-8")
    return hashlib.sha256(key).hexdigest(), identifier


def write_new(path, payload):
    handle = path.open("xb")
    try:
        with handle:
            handle.write(payload)
    except OSError:
        path.unlink()
        raise


def prepare(source, output, source_url, count, seed):
    raw = source.read_bytes()
    source_digest = hashlib.sha256(raw).hexdigest()
    official_release = source_digest == RELEASE_SHA256
    if source_url in {SOURCE, MIRROR} and not official_release:
        raise ValueError("source checksum differs from the published HotpotQA distractor development release")
    data = json.loads(raw)
    if not isinstance(data, list):
        raise ValueError("expected the original HotpotQA JSON array")
    by_id = {}
    excluded_pool_size = 0
    seen = set()
    for row in data:
        identifier = row["_id"]
        if not isinstance(identifier, str) or not identifier or identifier in seen:
            raise ValueError("HotpotQA example IDs must be nonempty and unique")
        seen.add(identifier)
        if len(row["context"]) != POOL_SIZE:
            excluded_pool_size += 1
            continue
        by_id[identifier] = row
    if count > len(by_id):
        raise ValueError(f"requested {count} examples but only {len(by_id)} have {POOL_SIZE} candidates")
    selected = sorted(by_id, key=lambda identifier: selection_key(identifier, seed))[:count]
    lines = [adapt(by_id[identifier]) for identifier in selected]
    payload = "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in lines).encode("utf-8")
    metadata = {
        "dataset": "HotpotQA",
        "split": "development",
        "setting": "distractor",
        "source": {"url": source_url, "file": source.name, "sha256": source_digest,
                   "matches_official_release": official_release},
        "reference": PAPER,
        "license": LICENSE,
        "source_rows": len(data),
        "eligible_rows": len(by_id),
        "excluded_wrong_candidate_count": excluded_pool_size,
        "questions": count,
        "selection": {"seed": seed, "key": f"SHA-256 of UTF-8 {SAMPLE_PREFIX}|<seed>|<_id>, then _id"},
        "ranking": {
            "method": "within-question BM25 of the released candidate pool",
            "candidates_per_question": POOL_SIZE,
            "tokenization": "Unicode alphanumerics excluding underscore after casefold",
            "k1": BM25_K1,
            "b": BM25_B,
            "tie_break": "original candidate order",
            "evidence": "document IDs of titles containing annotated supporting facts",
        },
        "manifest_sha256": hashlib.sha256(payload).hexdigest(),
    }
    sidecar = output.with_suffix(".meta.json")
    if output == sidecar or output.exists() or sidecar.exists():
        raise FileExistsError("choose a new manifest and metadata path")
    output.parent.mkdir(parents=True, exist_ok=True)
    metadata_bytes = (json.dumps(metadata, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    write_new(output, payload)
    try:
        write_new(sidecar, metadata_bytes)
    except OSError:
        output.unlink()
        raise
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Official hotpot_dev_distractor_v1.json")
    parser.add_argument("--source-url", default=SOURCE, help="Source URL recorded in provenance.")
    parser.add_argument("--out", type=Path, required=True, help="New output manifest JSONL path.")
    parser.add_argument("--count", type=int, default=200)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.count < 1:
        parser.error("--count must be positive")
    try:
        metadata = prepare(args.source, args.out, args.source_url, args.count, args.seed)
    except (OSError, TypeError, ValueError, KeyError) as error:
        parser.exit(1, f"HotpotQA preparation failed: {error}\n")
    print(f"Wrote {metadata['questions']} fixed-pool questions to {args.out}")


if __name__ == "__main__":
    main()
