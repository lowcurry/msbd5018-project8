"""Select the FLAN judge using the full development selection subset only."""
import argparse
from pathlib import Path
import statistics

import numpy as np

import evaluate
import models


def candidate(config, pred, rows, gold):
    spec = models.model_spec(config, "llm")
    path = pred / "llm_selection.jsonl"
    records = evaluate.unique(evaluate.read_jsonl(path), "id", path)
    if set(records) != {row["id"] for row in rows}:
        raise ValueError(f"{path} does not contain the full selection manifest.")
    predictions = []
    elapsed = []
    for row in rows:
        rec = records[row["id"]]
        if rec["text_hash"] != row["text_hash"] or rec["subset"] != "selection":
            raise ValueError(f"Stale or mismatched selection record for {row['id']}.")
        if rec["config_hash"] != models.config_hash(spec):
            raise ValueError(f"Wrong candidate configuration in {path}.")
        label = rec["pred_label"]
        if label is not None and label not in models.LABELS:
            raise ValueError(f"Invalid prediction label in {path}.")
        predictions.append(evaluate.LABEL_INDEX.get(label, evaluate.FAIL))
        elapsed.append(rec["elapsed_ms"])
    return {
        "model": spec["name"], "revision": spec["revision"],
        "config_hash": models.config_hash(spec), "predictions_sha256": models.file_digest(path),
        "median_pair_terminal_ms": statistics.median(elapsed),
        **evaluate.scores(gold, np.array(predictions)),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--base", type=Path, required=True, help="Prediction directory for FLAN-T5-base.")
    parser.add_argument("--small", type=Path, required=True, help="Prediction directory for FLAN-T5-small.")
    parser.add_argument("--out", type=Path, default=Path("results/dev/llm_selection.json"))
    parser.add_argument("--selected-config", type=Path, default=Path("configs/models_selected.json"))
    args = parser.parse_args()
    rows = models.inputs(args.data / "processed", "selection")
    if len(rows) != 2000:
        raise ValueError("Candidate comparison requires all 2,000 selection pairs.")
    gold = evaluate.read_gold(args.data / "restricted/gold_original.csv", rows)
    configs = (Path("configs/models.json"), Path("configs/models_flan_small.json"))
    dirs = (args.base, args.small)
    metrics = [candidate(c, d, rows, gold) for c, d in zip(configs, dirs)]
    # Latency tie break is meaningful only with an equal cache workload and local runtime.
    runtime = [models.read_json(d / "llm_selection.runtime.json") for d in dirs]
    if ({k: v for k, v in runtime[0].items() if k != "config_hash"}
            != {k: v for k, v in runtime[1].items() if k != "config_hash"}):
        raise ValueError("Candidate runtimes or batch sizes differ.")
    eligible = [i for i, m in enumerate(metrics) if m["failures"] < m["n"]]
    if not eligible:
        raise ValueError("Neither LLM candidate returned any valid label.")
    winner = min(eligible, key=lambda i: (-metrics[i]["macro_f1"], metrics[i]["median_pair_terminal_ms"], i))
    config = models.read_json(configs[0])
    config["llm"] = models.read_json(configs[winner])["llm"]
    if args.out.exists() or args.selected_config.exists():
        raise FileExistsError("Preserve the existing selection record and selected config.")
    evaluate.write_json(args.out, {
        "criterion": "maximize selection macro-F1, then lower same-load median latency, then base",
        "selected_model": metrics[winner]["model"], "config_hash": metrics[winner]["config_hash"],
        "selected_prediction_directory": str(dirs[winner]),
        "candidates": metrics, "n": len(rows), "subset": "selection",
    })
    evaluate.write_json(args.selected_config, config)
    print(f"Selected {metrics[winner]['model']} using the development selection subset.")


if __name__ == "__main__":
    main()
